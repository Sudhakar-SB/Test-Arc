-- DropIndex
DROP INDEX "Subject.paymentId_unique";
