-- CreateEnum
CREATE TYPE "SubjectStatus" AS ENUM ('Draft', 'Submitted');

-- CreateEnum
CREATE TYPE "Gender" AS ENUM ('Male', 'Female', 'Other');

-- CreateTable
CREATE TABLE "Symptom" (
    "key" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "regionKey" TEXT NOT NULL,
    "langEN" TEXT,
    "langES" TEXT,
    "langAR" TEXT,

    PRIMARY KEY ("key")
);

-- CreateTable
CREATE TABLE "SubjectSymptom" (
    "id" SERIAL NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "symptomKey" TEXT NOT NULL,
    "beginDate" TIMESTAMP(3) NOT NULL,
    "endDate" TIMESTAMP(3),
    "subjectId" INTEGER,

    PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "File" (
    "id" SERIAL NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "path" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "size" TEXT NOT NULL,
    "subjectId" INTEGER,

    PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Subject" (
    "id" SERIAL NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "userId" INTEGER NOT NULL,
    "status" "SubjectStatus" NOT NULL DEFAULT E'Draft',
    "paymentId" TEXT NOT NULL,
    "boxId" TEXT,
    "firstName" TEXT,
    "lastName" TEXT,
    "gender" "Gender",
    "birthDate" TIMESTAMP(3),
    "addressLine1" TEXT,
    "addressCity" TEXT,
    "addressPostCode" TEXT,
    "addressCountry" TEXT,
    "cancer" BOOLEAN,
    "miscarriage" BOOLEAN,
    "unexplainedDeath" BOOLEAN,
    "longTermTreatment" BOOLEAN,
    "mentalHealthIssues" BOOLEAN,
    "heartProblems" BOOLEAN,
    "organTransplantation" BOOLEAN,
    "visionLoss" BOOLEAN,
    "hearingLoss" BOOLEAN,
    "stroke" BOOLEAN,
    "height" DECIMAL(65,30),
    "weight" DECIMAL(65,30),
    "formConsent" BOOLEAN,
    "researchConsent" BOOLEAN,
    "incidentalFindingsConsent" BOOLEAN,

    PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "SubjectSymptom" ADD FOREIGN KEY ("symptomKey") REFERENCES "Symptom"("key") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SubjectSymptom" ADD FOREIGN KEY ("subjectId") REFERENCES "Subject"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "File" ADD FOREIGN KEY ("subjectId") REFERENCES "Subject"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Subject" ADD FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
