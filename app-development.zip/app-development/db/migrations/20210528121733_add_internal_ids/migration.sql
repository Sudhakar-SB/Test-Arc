-- AlterTable
ALTER TABLE "Subject" ADD COLUMN     "internalId" SERIAL NOT NULL;

-- AlterTable
ALTER TABLE "User" ADD COLUMN     "internalId" SERIAL NOT NULL;
