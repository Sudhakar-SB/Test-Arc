-- AlterTable
ALTER TABLE "SubjectSymptom" ADD COLUMN     "ongoing" BOOLEAN NOT NULL DEFAULT true;
