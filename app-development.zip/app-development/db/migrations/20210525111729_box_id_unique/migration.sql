/*
  Warnings:

  - A unique constraint covering the columns `[boxId]` on the table `Subject` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateIndex
CREATE UNIQUE INDEX "Subject.boxId_unique" ON "Subject"("boxId");
