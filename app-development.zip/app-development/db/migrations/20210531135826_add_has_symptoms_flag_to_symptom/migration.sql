-- AlterTable
ALTER TABLE "Subject" ADD COLUMN     "hasSymptoms" BOOLEAN;
