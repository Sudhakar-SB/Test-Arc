-- AlterTable
ALTER TABLE "Subject" ADD COLUMN     "sampleCollectionDate" TIMESTAMP(3);
