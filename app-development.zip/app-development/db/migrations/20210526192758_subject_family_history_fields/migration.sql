/*
  Warnings:

  - The `cancer` column on the `Subject` table would be dropped and recreated. This will lead to data loss if there is data in the column.
  - The `miscarriage` column on the `Subject` table would be dropped and recreated. This will lead to data loss if there is data in the column.
  - The `unexplainedDeath` column on the `Subject` table would be dropped and recreated. This will lead to data loss if there is data in the column.
  - The `longTermTreatment` column on the `Subject` table would be dropped and recreated. This will lead to data loss if there is data in the column.
  - The `mentalHealthIssues` column on the `Subject` table would be dropped and recreated. This will lead to data loss if there is data in the column.
  - The `heartProblems` column on the `Subject` table would be dropped and recreated. This will lead to data loss if there is data in the column.
  - The `organTransplantation` column on the `Subject` table would be dropped and recreated. This will lead to data loss if there is data in the column.
  - The `visionLoss` column on the `Subject` table would be dropped and recreated. This will lead to data loss if there is data in the column.
  - The `hearingLoss` column on the `Subject` table would be dropped and recreated. This will lead to data loss if there is data in the column.
  - The `stroke` column on the `Subject` table would be dropped and recreated. This will lead to data loss if there is data in the column.

*/
-- CreateEnum
CREATE TYPE "YesNoUnknown" AS ENUM ('Yes', 'No', 'Unknown');

-- AlterTable
ALTER TABLE "Subject" DROP COLUMN "cancer",
ADD COLUMN     "cancer" "YesNoUnknown",
DROP COLUMN "miscarriage",
ADD COLUMN     "miscarriage" "YesNoUnknown",
DROP COLUMN "unexplainedDeath",
ADD COLUMN     "unexplainedDeath" "YesNoUnknown",
DROP COLUMN "longTermTreatment",
ADD COLUMN     "longTermTreatment" "YesNoUnknown",
DROP COLUMN "mentalHealthIssues",
ADD COLUMN     "mentalHealthIssues" "YesNoUnknown",
DROP COLUMN "heartProblems",
ADD COLUMN     "heartProblems" "YesNoUnknown",
DROP COLUMN "organTransplantation",
ADD COLUMN     "organTransplantation" "YesNoUnknown",
DROP COLUMN "visionLoss",
ADD COLUMN     "visionLoss" "YesNoUnknown",
DROP COLUMN "hearingLoss",
ADD COLUMN     "hearingLoss" "YesNoUnknown",
DROP COLUMN "stroke",
ADD COLUMN     "stroke" "YesNoUnknown";
