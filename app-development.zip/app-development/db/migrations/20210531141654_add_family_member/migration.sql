-- AlterTable
ALTER TABLE "Subject" ADD COLUMN     "familyMember" BOOLEAN;
