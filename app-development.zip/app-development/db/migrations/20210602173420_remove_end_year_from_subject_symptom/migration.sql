/*
  Warnings:

  - You are about to drop the column `endYear` on the `SubjectSymptom` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "SubjectSymptom" DROP COLUMN "endYear";
