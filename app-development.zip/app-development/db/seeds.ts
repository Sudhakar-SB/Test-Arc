import db from "db"
import data from "./data/boxIds.json"

/*
 * This seed function is executed when you run `blitz db seed`.
 *
 * Probably you want to use a library like https://chancejs.com
 * or https://github.com/Marak/Faker.js to easily generate
 * realistic data.
 */
const seed = async () => {
  const boxIds = data.boxIds

  for (const id of boxIds) {
    await db.box.create({ data: { id } })
  }
}

export default seed
