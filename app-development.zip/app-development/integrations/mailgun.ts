import Mailgun from "mailgun.js"
import AbortController from "node-abort-controller"
// workaround for https://github.com/mailgun/mailgun-js/issues/101
// @ts-ignore-next-line
global.AbortController = AbortController

const formData = require("form-data")

const mailgun = new Mailgun(formData)

const mg = mailgun.client({
  username: "api",
  key: process.env.MAILGUN_API_KEY!,
  url: process.env.MAILGUN_API_URL,
})

export default mg
