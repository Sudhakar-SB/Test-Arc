# Arcenus Customer Portal

For general BlitzJS README check [BLITZ_README.md](BLITZ_README.md)

## Getting Started

Start development db

```
docker-compose up
```

Seed data

```
blitz db seed
```

Run your app in the development mode.

```
blitz start
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

## Environment Variables

Ensure the `.env.local` file has required environment variables:
You can use .env.example as template

```
DATABASE_URL=postgresql://<YOUR_DB_USERNAME>@localhost:5432/yade-app
```

## Manage AWS resources

We have an S3 bucket.

See (infra docs)[./docs/aws-cdk-setup.md] for cdk setup

## Manage Render.com deployment

Defines web app service instance, cron jobs and postgres database

`render.yaml`

Render.com will try to sync any pushed changes in master branch (gitlab) to that file into the production environment,
check progress on render dashboard: https://dashboard.render.com/

## Architecture

- Single monolithic webapp (react front & backend hosted in same repo)
- API is BlitzJS magic. I.e. it is opaque to us how api calls are made. Frontend components calling backend code (queries & mutations) get re-written in the background to api calls.
- PostgreSQL for perstience, Prisma2 to interface with Postgres and manage db migration.
