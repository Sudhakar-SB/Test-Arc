module.exports = {
  i18n: {
    locales: process.env.SUPPORTED_LANGUAGES?.split(",") ?? ["en"],
    defaultLocale: process.env.DEFAULT_LANGUAGE,
    debug: true && process.env.NODE_ENV !== "production",
    localeDetection: true,
  },
}
