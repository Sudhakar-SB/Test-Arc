module.exports = {
  extends: ["blitz"],
}
