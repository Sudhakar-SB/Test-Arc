const core = require("@aws-cdk/core")
const s3 = require("@aws-cdk/aws-s3")
const iam = require("@aws-cdk/aws-iam")

class CdkStack extends core.Stack {
  createUserAndBucket(userName, bucketName, allowedOrigins) {
    const user = iam.User.fromUserName(this, `${userName}-user`, userName)

    // Create bucket for uploads
    const bucket = new s3.Bucket(this, bucketName, {
      bucketName: `${bucketName}-files`,
      removalPolicy: core.RemovalPolicy.DESTROY,
      accessControl: s3.BucketAccessControl.PRIVATE,
      publicReadAccess: false,
      cors: [
        {
          allowedHeaders: ["*"],
          allowedMethods: ["PUT", "DELETE", "POST"],
          allowedOrigins,
        },
      ],
    })

    // Create policy giving access to the stuff the user will need
    const policy = new iam.ManagedPolicy(this, `${userName}-policy`, {
      managedPolicyName: `${userName}-policy`,
    })

    policy.addStatements(
      new iam.PolicyStatement({
        effect: iam.Effect.ALLOW,
        resources: [`${bucket.bucketArn}/*`],
        actions: ["*"],
      })
    )
    // Attach policy to arcensus user
    policy.attachToUser(user)
  }

  constructor(scope) {
    super(scope, "ArcensusStack", {
      env: {
        region: "eu-central-1",
      },
    })

    this.createUserAndBucket("customer-portal", "arcensus", [
      "https://portal.arcensus-diagnostics.com",
    ])
    this.createUserAndBucket("customer-portal-dev", "arcensus-dev", [
      "http://localhost:3002",
      "https://dev-portal.arcensus-diagnostics.com",
    ])
  }
}

module.exports = { CdkStack }
