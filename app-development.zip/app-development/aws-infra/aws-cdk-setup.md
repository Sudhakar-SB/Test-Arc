# AWS resources setup with CDK

Some manual setup is first required.

# Create a user named `arcensus-app-user`

We have an S3 bucket is managed via cloudformation, defined in a CDK stack.
`aws-infra/cdk-stack.js`

You will need the aws cli and valid aws keys
`brew install awscli`
`aws configure`

Diff cdk stack definition to what is deployed
`yarn cdk diff`

Deploy changes
`yarn cdk deploy`

If you have multiple AWS accounts and different profiles for them, make sure you use the correct profile for whichever AWS account you're deploying.
e.g.
`AWS_PROFILE=makersden yarn cdk deploy`
`AWS_PROFILE=arcensus yarn cdk deploy`
