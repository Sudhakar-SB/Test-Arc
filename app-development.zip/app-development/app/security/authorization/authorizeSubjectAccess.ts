import { AuthorizationError, Ctx, NotFoundError } from "blitz"
import db, { Subject, SubjectSymptom, SubjectFile } from "db"

export type AuthorizedSubject = Subject & { symptoms: SubjectSymptom[]; files: SubjectFile[] }

const authorizeSubjectAccess = async (
  subjectId: Subject["id"],
  ctx: Ctx
): Promise<AuthorizedSubject> => {
  const sessionUserId = ctx.session.userId

  if (!sessionUserId) {
    throw new AuthorizationError()
  }

  const subject = await db.subject.findFirst({
    where: {
      id: subjectId,
      userId: sessionUserId,
    },
    include: { symptoms: true, files: true },
  })

  if (!subject) {
    throw new NotFoundError()
  }

  if (subject.userId !== sessionUserId) {
    throw new AuthorizationError()
  }

  return subject
}

export default authorizeSubjectAccess
