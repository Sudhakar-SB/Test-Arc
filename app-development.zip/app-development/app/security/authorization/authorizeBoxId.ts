import db from "db"
import SuperJson from "superjson"

export class BoxIdInvalidError extends Error {}
SuperJson.registerClass(BoxIdInvalidError, { identifier: "BoxIdInvalidError" })

const authorizeBoxId = async (boxId: string, subjectId: string) => {
  const isBoxIdValid = 0 < (await db.box.count({ where: { id: boxId } }))

  if (!isBoxIdValid) {
    throw new BoxIdInvalidError()
  }

  const isBoxIdTaken = 0 < (await db.subject.count({ where: { boxId, NOT: { id: subjectId } } }))

  if (isBoxIdTaken) {
    throw new BoxIdInvalidError()
  }
}

export default authorizeBoxId
