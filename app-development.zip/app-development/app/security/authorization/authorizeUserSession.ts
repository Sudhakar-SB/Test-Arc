import { AuthorizationError, Ctx } from "blitz"
import { User } from "db"

const authorizeUserSession = (userId: User["id"], ctx: Ctx) => {
  const hasAuthorization = userId === ctx.session.userId

  if (!hasAuthorization) {
    throw new AuthorizationError()
  }
}

export default authorizeUserSession
