import { AuthorizationError } from "blitz"
import db from "db"
import { parsePaymentId, PaymentIdFormat, PaymentIdType } from "../../subjects/utils/parsePaymentId"
import SuperJson from "superjson"

// https://blitzjs.com/docs/error-handling
// https://github.com/blitz-js/superjson/issues/116#issuecomment-773996564
export class PaymentIdTakenError extends Error {}
SuperJson.registerClass(PaymentIdTakenError, { identifier: "PaymentIdTakenError" })

const authorizePaymentId = async (paymentId: string) => {
  const [type, format] = parsePaymentId(paymentId)

  // Amazon order ids can be used multiple times
  if (type === PaymentIdType.AMAZON && format === PaymentIdFormat.VALID_FORMAT) {
    return
  }

  // This should never happen because if input validation, but let's be safe
  if (type !== PaymentIdType.ARCENSUS || format !== PaymentIdFormat.VALID_FORMAT) {
    throw new AuthorizationError()
  }

  // We now have an arcensus order id in valid format
  // We count the subjects with the same paymentId
  // It should be zero
  const failureCount = await db.subject.count({ where: { paymentId } })

  if (failureCount > 0) {
    throw new PaymentIdTakenError()
  }
}

export default authorizePaymentId
