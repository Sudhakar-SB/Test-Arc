import { Ctx } from "blitz"
import { Subject, SubjectStatus } from "db"
import authorizeSubjectAccess from "./authorizeSubjectAccess"

const authorizeSubjectMutation = async (subjectId: Subject["id"], ctx: Ctx) => {
  const subject = await authorizeSubjectAccess(subjectId, ctx)

  if (subject.status === SubjectStatus.Submitted) {
    throw new Error("Subject has already been submitted.")
  }

  return subject
}

export default authorizeSubjectMutation
