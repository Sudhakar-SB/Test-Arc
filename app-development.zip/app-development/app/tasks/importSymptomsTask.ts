import db, { Symptom } from "db"
import symptoms from "./symptoms.json"

async function run() {
  // Note: would be ideal if we could apply a row level lock on this message (SELECT FOR UPDATE)
  // until we've been able to update its status to 'Sending'.
  // For now will not be an issue since we will have a single cron job running this task,
  // and no task will be run in parallel

  console.log(`Starting to import ${symptoms.length} symptoms...`)

  let createdSymptoms: Partial<Symptom>[] = []
  let updatedSymptoms: Symptom[] = []

  for (const symptom of symptoms) {
    const { key, ...data } = symptom
    const existing = await db.symptom.findFirst({ where: { key } })
    if (existing) {
      console.log(`updating ${key}`)
      const updated = await db.symptom.update({ where: { key }, data })
      updatedSymptoms.push(updated)
    } else {
      console.log(`creating ${key}`)
      const created = await db.symptom.create({ data: { key, ...data } })
      createdSymptoms.push(created)
    }
  }

  console.log(
    `Import symptoms task complete, created ${createdSymptoms.length} new symptoms & updated ${updatedSymptoms.length} symptoms`
  )

  await db.$disconnect()
}

run()
