import { resolver } from "blitz"
import db, { Prisma } from "db"

interface GetSymptomInput extends Prisma.SymptomFindUniqueArgs {}

export default resolver.pipe(resolver.authorize(), async (input: GetSymptomInput) => {
  // TODO: in multi-tenant app, you must add validation to ensure correct tenant
  const symptoms = await db.symptom.findUnique(input)

  return symptoms
})
