import { resolver } from "blitz"
import db, { Prisma } from "db"

interface GetSymptomsInput extends Pick<Prisma.SymptomFindManyArgs, "where" | "orderBy"> {}

export default resolver.pipe(resolver.authorize(), async ({ where, orderBy }: GetSymptomsInput) => {
  // TODO: in multi-tenant app, you must add validation to ensure correct tenant
  const symptoms = await db.symptom.findMany({ where, orderBy })

  return symptoms
})
