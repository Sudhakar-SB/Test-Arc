import { useRouter } from "@blitzjs/core"
import { CloseIcon, SearchIcon } from "@chakra-ui/icons"
import {
  Box,
  Flex,
  Heading,
  Icon,
  IconButton,
  Input,
  InputGroup,
  InputLeftElement,
  InputRightElement,
  Select,
} from "@chakra-ui/react"
import debounce from "app/core/utils/debounce"
import { Prisma, Symptom } from "db"
import React, { FC, Suspense, useEffect, useState } from "react"
import { IoLanguage } from "react-icons/io5"
import { Region } from "../constants/regions"
import RegionSelector from "./RegionSelector"
import SymptomList, { SymptomListLoader } from "./SymptomList"

interface Props {
  onSymptomClick?: (symptom: Symptom) => void
  selectedKeys: Symptom["key"][]
}

const SymptomFinder: FC<Props> = ({ onSymptomClick, selectedKeys }) => {
  const router = useRouter()
  const [search, setSearch] = useState<string>("")
  const [where, setWhere] = useState<Prisma.SymptomWhereInput>({})

  const handleRegionChange = (regions: (Region | undefined)[]) => {
    const [parentRegion, childRegion] = regions

    if (childRegion) {
      setWhere({ ...where, regionKey: childRegion.key })
    } else if (parentRegion) {
      setWhere({
        ...where,
        regionKey: { in: [parentRegion.key, ...(parentRegion.childRegionKeys ?? [])] },
      })
    } else {
      setWhere({ ...where, regionKey: undefined })
    }
  }

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearch(e.target.value)
  }

  const labelKey = `lang${router.locale?.toUpperCase() ?? "EN"}`

  useEffect(() => {
    debounce(() => setWhere((where) => ({ ...where, [labelKey]: { contains: search } })), 500)()
  }, [search, labelKey])

  return (
    <>
      <Flex h="300px">
        <RegionSelector w="180px" h="100%" overflow="hidden" onRegionChange={handleRegionChange} />
        <Box flex="1" ml={4} display="flex" flexDirection="column" overflow="hidden">
          <Flex>
            <InputGroup>
              <Input
                placeholder="Search Symptoms..."
                value={search}
                onChange={handleSearchChange}
              />
              <InputRightElement>
                {search ? (
                  <IconButton
                    aria-label="clear search"
                    size="sm"
                    isRound
                    colorScheme="gray"
                    onClick={() => setSearch("")}
                  >
                    <CloseIcon h={3} w={3} />
                  </IconButton>
                ) : (
                  <SearchIcon color="gray.300" />
                )}
              </InputRightElement>
            </InputGroup>

            <InputGroup flex="0">
              <InputLeftElement>
                <Icon as={IoLanguage} color="gray.500" />
              </InputLeftElement>
              <Select
                pl={10}
                w="120px"
                defaultValue={router.locale}
                onChange={(e) => {
                  router.replace(router.asPath, undefined, { locale: e.target.value })
                  setSearch("")
                }}
              >
                {router.locales?.map((locale) => {
                  return (
                    <option key={locale} value={locale}>
                      {locale.toUpperCase()}
                    </option>
                  )
                })}
              </Select>
            </InputGroup>
          </Flex>

          <Heading size="sm" mt={3}>
            Select Symptoms
          </Heading>

          <Suspense fallback={<SymptomListLoader mt={1} />}>
            <SymptomList
              selectedKeys={selectedKeys}
              mt={1}
              where={where}
              onSymptomClick={onSymptomClick}
              flex="1"
            />
          </Suspense>
        </Box>
      </Flex>
    </>
  )
}

export default SymptomFinder
