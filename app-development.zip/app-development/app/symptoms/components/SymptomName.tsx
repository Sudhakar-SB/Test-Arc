import { useQuery, useRouter } from "@blitzjs/core"
import { Box, Skeleton, Text, TextProps } from "@chakra-ui/react"
import getSymptom from "app/symptoms/queries/getSymptom"
import { FC } from "react"

interface Props extends TextProps {
  symptomKey: string
}

const SymptomName: FC<Props> = ({ symptomKey, ...props }) => {
  const router = useRouter()
  const labelKey = `lang${router.locale?.toUpperCase() ?? "EN"}`
  const [symptom] = useQuery(getSymptom, { where: { key: symptomKey } })
  const isRTL = router.locale === "ar"

  return (
    <Text as="span" display="block" style={{ direction: isRTL ? "rtl" : "ltr" }} {...props}>
      {symptom?.[labelKey]}
    </Text>
  )
}

export default SymptomName

export const SymptomNameLoader = () => (
  <Box display="flex">
    <Skeleton height="20px" width="90px" />
    <Skeleton height="20px" width="30px" ml={1} />
    <Skeleton height="20px" width="60px" ml={1} />
  </Box>
)
