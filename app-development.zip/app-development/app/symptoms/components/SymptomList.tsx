import { CheckCircleIcon } from "@chakra-ui/icons"
import { Flex } from "@chakra-ui/layout"
import { Box, BoxProps, Button, Skeleton, Text } from "@chakra-ui/react"
import { useQuery, useRouter } from "blitz"
import { Prisma, Symptom } from "db"
import { FC } from "react"
import { FixedSizeList } from "react-window"
import getSymptoms from "../queries/getSymptoms"

const SymptomButton = ({ index, style, data }) => {
  const router = useRouter()
  const labelKey = `lang${router.locale?.toUpperCase() ?? "EN"}`
  const isRTL = router.locale === "ar"
  const { symptoms, onClick, selectedKeys } = data
  const symptom = symptoms[index]
  const isSelected = selectedKeys.indexOf(symptom.key) > -1

  return (
    <Button
      variant="unstyled"
      p="none"
      px={3}
      py={2}
      cursor="pointer"
      width="100%"
      display="flex"
      alignItems="center"
      justifyContent="space-between"
      borderRadius={0}
      fontWeight="normal"
      _hover={{ background: "gray.100" }}
      role="group"
      height="auto"
      onClick={() => onClick(symptom)}
      style={style}
      flexDirection={isRTL ? "row-reverse" : "row"}
      isDisabled={isSelected}
    >
      <Text whiteSpace="normal" textAlign="left">
        {symptom[labelKey]}
      </Text>
      {isSelected ? (
        <CheckCircleIcon color="green.500" />
      ) : (
        <Text fontWeight="bold" opacity={0} _groupHover={{ opacity: 1 }} fontSize="sm">
          Add
        </Text>
      )}
    </Button>
  )
}

interface Props extends BoxProps {
  where: Prisma.SymptomFindManyArgs["where"]
  onSymptomClick?: (symptom: Symptom) => void
  selectedKeys: Symptom["key"][]
}

const SymptomList: FC<Props> = ({ where, onSymptomClick, selectedKeys, ...restProps }) => {
  const router = useRouter()
  const labelKey = `lang${router.locale?.toUpperCase() ?? "EN"}`
  const [symptoms] = useQuery(getSymptoms, { where, orderBy: { [labelKey]: "asc" } })

  const handleSymptomClick = (symptom: Symptom) => {
    onSymptomClick && onSymptomClick(symptom)
  }

  return (
    <Box
      border="1px solid"
      borderColor="gray.200"
      overflow="auto"
      borderRadius="md"
      background="white"
      {...restProps}
    >
      <FixedSizeList
        itemCount={symptoms.length}
        itemSize={50}
        height={223}
        width="100%"
        itemData={{ symptoms, onClick: handleSymptomClick, selectedKeys }}
      >
        {SymptomButton}
      </FixedSizeList>
    </Box>
  )
}

export default SymptomList

const SkeletonLine = ({ widths }: { widths: string[] }) => (
  <Flex px={3} py={2}>
    {widths.map((w) => (
      <Skeleton key={w} height="16px" w={w} ml={1} />
    ))}
  </Flex>
)

export const SymptomListLoader = ({ ...restProps }) => (
  <Box
    border="1px solid"
    borderColor="gray.200"
    overflow="auto"
    borderRadius="md"
    background="white"
    alignItems="flex-start"
    py={3}
    flex="1"
    {...restProps}
  >
    <SkeletonLine widths={["60px", "30px", "90px"]} />
    <SkeletonLine widths={["20px", "70px", "10px"]} />
    <SkeletonLine widths={["30px", "40px", "50px"]} />
  </Box>
)
