import { useRouter } from "@blitzjs/core"
import { ChevronLeftIcon, ChevronRightIcon, CloseIcon } from "@chakra-ui/icons"
import { Box, BoxProps, Button, Heading, HStack, IconButton, Text } from "@chakra-ui/react"
import React, { FC, useEffect, useState } from "react"
import regions, { Region } from "../constants/regions"

interface Props extends BoxProps {
  onRegionChange?: (selected: (Region | undefined)[]) => void
}

const RegionSelector: FC<Props> = ({ onRegionChange, ...restProps }) => {
  const router = useRouter()
  const [parentRegion, setParent] = useState<Region | undefined>(undefined)
  const [childRegion, setChild] = useState<Region | undefined>(undefined)
  const [renderedRegions, setRendered] = useState<Region[]>(regions)

  const setRegions = (regions: (Region | undefined)[]) => {
    const [parentRegion, childRegion] = regions
    setParent(parentRegion)
    setChild(childRegion)
    const selected = [parentRegion, childRegion]
    onRegionChange && onRegionChange(selected)
  }

  // controls what's rendered at any given state
  useEffect(() => {
    if (parentRegion && parentRegion.childRegions) {
      if (parentRegion.childRegions.length > 0) {
        setRendered(parentRegion.childRegions)
      }
    }
    if (parentRegion === undefined) {
      setRendered(regions)
    }
  }, [parentRegion])

  const labelKey = `lang${router.locale?.toUpperCase() ?? "EN"}`
  const isRTL = router.locale === "ar"

  return (
    <Box {...restProps}>
      <HStack
        bg="gray.100"
        h="45px"
        border="1px solid"
        borderColor="gray.200"
        p={3}
        justifyContent="space-between"
        borderTopRadius="md"
      >
        <Heading size="sm">
          {parentRegion?.childRegions ? (
            <>
              <Button
                aria-label="back"
                size="sm"
                variant="unstyled"
                onClick={() => setRegions([])}
                display="inline-flex"
                alignItems="center"
                justifyContent="center"
                borderRadius="0"
                padding={0}
                ml={-1}
              >
                <ChevronLeftIcon h={6} w={6} mr={1} />
                <Text fontSize="md" position="relative" bottom="-1px">
                  {parentRegion?.[labelKey]}
                </Text>
              </Button>
            </>
          ) : (
            "Filter by body part"
          )}
        </Heading>
        {(parentRegion || childRegion) && (
          <Button size="sm" colorScheme="blue" variant="link" onClick={() => setRegions([])}>
            Reset
          </Button>
        )}
      </HStack>
      <Box
        h="calc(100% - 45px)"
        overflow="auto"
        border="1px solid"
        borderTop="none"
        borderColor="gray.200"
        borderBottomRadius="md"
      >
        {renderedRegions.map((region) => {
          const { key, childRegions } = region
          const isSelected = [parentRegion, childRegion].indexOf(region) > -1
          const isChild = !!region.parentRegion
          const hasChildren = !!childRegions
          return (
            <Box position="relative" key={key}>
              <Button
                variant="unstyled"
                display="flex"
                p={3}
                cursor="pointer"
                width="100%"
                alignItems="center"
                justifyContent="space-between"
                borderRadius={0}
                fontWeight="normal"
                onClick={() =>
                  isChild ? setRegions([parentRegion, region]) : setRegions([region])
                }
                _hover={{ background: isSelected ? "brand.expertBlue" : "gray.100" }}
                {...(isSelected ? { background: "brand.expertBlue", color: "white" } : {})}
                flexDirection={isRTL ? "row-reverse" : "row"}
              >
                <Text>{region[labelKey]}</Text>
                {hasChildren && <ChevronRightIcon h={6} w={6} />}
              </Button>
              {isSelected && (
                <IconButton
                  aria-label="deselect"
                  size="sm"
                  isRound
                  variant="ghost"
                  color="white"
                  _hover={{ background: "expertBlue.600", color: "white" }}
                  position="absolute"
                  top="50%"
                  right={isRTL ? undefined : 1}
                  left={isRTL ? 1 : undefined}
                  transform="translateY(-50%)"
                  onClick={() => (isChild ? setRegions([parentRegion]) : setRegions([]))}
                >
                  <CloseIcon h={3} w={3} />
                </IconButton>
              )}
            </Box>
          )
        })}
      </Box>
    </Box>
  )
}

export default RegionSelector
