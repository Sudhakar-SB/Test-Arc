import regionsWithoutRelations from "./regions"

export { regionsWithoutRelations as regions }
