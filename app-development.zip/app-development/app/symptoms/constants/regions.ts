export interface Region {
  key: string
  langEN: string
  langES: string
  langAR?: string
  parentRegion?: Region
  parentRegionKey?: string
  childRegions?: Region[]
  childRegionKeys?: string[]
}

const regionsWithoutRelations: Region[] = [
  {
    key: "general",
    langEN: "General",
    langES: "General",
    langAR: "عام",
  },
  {
    key: "skelet",
    langEN: "Skelet",
    langES: "Esqueleto",
    langAR: "هيكل عظمي",
  },
  {
    key: "head",
    langEN: "Head",
    langES: "Cabeza",
    langAR: "الرأس",
  },
  {
    key: "eye",
    langEN: "Eye",
    langES: "Ojos",
    langAR: "العين",
    parentRegionKey: "head",
  },
  {
    key: "brain",
    langEN: "Brain",
    langES: "Cerebro",
    langAR: "المخ",
    parentRegionKey: "head",
  },
  {
    key: "skull",
    langEN: "Scalp/Skull",
    langES: "Cráneo",
    langAR: "فروة الرأس / الجمجمة",
    parentRegionKey: "head",
  },
  {
    key: "nose",
    langEN: "Nose",
    langES: "Nariz",
    langAR: "الأنف",
    parentRegionKey: "head",
  },
  {
    key: "ear",
    langEN: "Ear",
    langES: "Oído",
    langAR: "الأذن",
    parentRegionKey: "head",
  },
  {
    key: "face",
    langEN: "Face",
    langES: "Cara",
    langAR: "الوجه",
    parentRegionKey: "head",
  },
  {
    key: "mouth",
    langEN: "Mouth",
    langES: "Boca",
    langAR: "الفم",
    parentRegionKey: "head",
  },
  {
    key: "neck",
    langEN: "Neck",
    langES: "Cuello",
    langAR: "العنق",
  },
  {
    key: "chest",
    langEN: "Chest",
    langES: "Pecho",
    langAR: "الصدر",
  },
  {
    key: "arms",
    langEN: "Arms",
    langES: "Brazos",
    langAR: "الذراعان",
  },
  {
    key: "legs",
    langEN: "Legs",
    langES: "Piernas",
    langAR: "القدمان",
  },
  {
    key: "belly",
    langEN: "Belly",
    langES: "Estómago",
    langAR: "البطن",
  },
  {
    key: "pelvis",
    langEN: "Pelvis",
    langES: "Pelvis",
    langAR: "الحوض",
  },
  {
    key: "back",
    langEN: "Back",
    langES: "Espalda",
    langAR: "الظهر",
  },
  {
    key: "buttock",
    langEN: "Buttock",
    langES: "Glúteos",
    langAR: "المؤخرة",
  },
]

const regionsWithParentRegions: Region[] = regionsWithoutRelations.map((region) => {
  const parentRegion = regionsWithoutRelations.find(({ key }) => key === region.parentRegionKey)
  return {
    ...region,
    parentRegion,
  }
})

const regions: Region[] = regionsWithParentRegions
  .map((region) => {
    const childRegions = regionsWithParentRegions.filter(
      ({ parentRegionKey }) => parentRegionKey === region.key
    )
    return {
      ...region,
      childRegions: childRegions.length > 0 ? childRegions : undefined,
      childRegionKeys: childRegions.map(({ key }) => key),
    }
  })
  .filter(({ parentRegionKey }) => !parentRegionKey)

export default regions
