import { Heading } from "@chakra-ui/layout"
import Layout from "app/core/layouts/Layout"
import { BlitzPage } from "blitz"
import { Center, Spinner } from "@chakra-ui/react"
import { Suspense } from "react"
import SamplePickupForm from "../../components/SamplePickupForm"

export const SamplePickupPage: BlitzPage = () => {
  return (
    <>
      <Heading size="lg">Sample pickup</Heading>

      <Suspense
        fallback={
          <Center height="200px">
            <Spinner />
          </Center>
        }
      >
        <SamplePickupForm />
      </Suspense>
    </>
  )
}

SamplePickupPage.authenticate = true
SamplePickupPage.getLayout = (page) => (
  <Layout hasSidebar title="Sample pickup" px={12} py={10}>
    {page}
  </Layout>
)

export default SamplePickupPage
