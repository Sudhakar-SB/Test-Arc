import { FC, ReactNode } from "react"
import { Box } from "@chakra-ui/layout"

interface Props {
  onClick: () => void
  selected: boolean
  children: ReactNode
}

const CountryBox: FC<Props> = ({ children, onClick, selected }) => {
  return (
    <Box
      w="100%"
      borderWidth="1px"
      borderRadius="lg"
      p="2"
      textAlign="center"
      bg={selected ? "brand.expertBlue" : undefined}
      color={selected ? "white" : undefined}
      _hover={{ bg: selected ? undefined : "gray.200" }}
      cursor="pointer"
      onClick={onClick}
    >
      {children}
    </Box>
  )
}

export default CountryBox
