import { Button } from "@chakra-ui/button"
import { Box, Heading, Link, LinkOverlay, Text, UnorderedList } from "@chakra-ui/layout"
import { Grid, ListItem, OrderedList } from "@chakra-ui/react"
import { FC, useState } from "react"
import CountryBox from "./CountryBox"

const PersonalInfoForm: FC = () => {
  const [country, setCountry] = useState("")

  return (
    <>
      <Text mt={6} mb={2}>
        Choose your country:
      </Text>

      <Grid templateColumns="repeat(2, 1fr)" gap={6}>
        <CountryBox
          onClick={() => setCountry("saudi-arabia")}
          selected={country === "saudi-arabia"}
        >
          <Text fontSize="4xl">
            <span role="img" aria-label="Flag of Saudi Arabia">
              🇸🇦
            </span>
          </Text>
          Saudi Arabia
        </CountryBox>

        <CountryBox onClick={() => setCountry("spain")} selected={country === "spain"}>
          <Text fontSize="4xl">
            <span role="img" aria-label="Flag of Spain">
              🇪🇸
            </span>
          </Text>
          Spain
        </CountryBox>
      </Grid>

      {country === "saudi-arabia" && (
        <>
          <Heading size="md" mt={6} mb={4}>
            Instructions for Saudi Arabia
          </Heading>
          <OrderedList>
            <ListItem>
              After providing all mandatory information you are ready to ship your sample
            </ListItem>
            <ListItem>
              To organise a pick-up of your sample, send an Email one day in advance with:
            </ListItem>
            <UnorderedList>
              <ListItem>The preferred pick-up time slot (minimum of 3 hours)</ListItem>
              <ListItem>Detailed address (including building number, floor etc)</ListItem>
              <ListItem>Contact mobile phone number</ListItem>
            </UnorderedList>
            <p>
              to:{" "}
              <Link color="blue.600" href="mailto:logisticsKSA@arcensus-diagnostics.com">
                logisticsKSA@arcensus-diagnostics.com
              </Link>
            </p>
            <ListItem>You will receive a confirmation via an Email with pick-up details</ListItem>
          </OrderedList>
        </>
      )}

      {country === "spain" && (
        <>
          <Heading size="md" mt={6} mb={4}>
            Instructions for Spain
          </Heading>
          <OrderedList>
            <ListItem>
              After providing all mandatory information you are ready to ship your sample
            </ListItem>
            <ListItem>
              Use the following link to order the pick-up service of DHL Express Spain:
              <Box>
                <Button>
                  <LinkOverlay
                    href="https://myepp.dhl.com/gw/premiumweb/public/LoginByHash.action?hash=6c128370ba7302b38110db528447b6ec3f8926a371f8f50f3950a94f68b999df"
                    isExternal
                  >
                    Send to arcensus
                  </LinkOverlay>
                </Button>
              </Box>
            </ListItem>
            <ListItem>Enter your address details (mandatory fields are marked with *)</ListItem>
            <ListItem>Choose your desired pick-up time window and book the shipment</ListItem>
            <ListItem>
              Print the label and stick it to the return bag. Note that the ‘EXEMPT HUMAN SPECIMEN’
              must not be covered
            </ListItem>
            <ListItem>
              For questions to DHL Express call{" "}
              <Link href="tel:902122424" isExternal>
                902 12 24 24
              </Link>
              .
            </ListItem>
          </OrderedList>
        </>
      )}
    </>
  )
}

export default PersonalInfoForm
