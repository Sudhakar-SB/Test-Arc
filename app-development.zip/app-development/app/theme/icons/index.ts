// Tips for generating your own icons
// https://chakra-ui.com/docs/components/icon#tips-for-generating-your-own-icons
import { IconProps } from "@chakra-ui/react"
import AddPersonIcon from "./AddPerson"
import AddSampleIcon from "./AddSample"
import AddTestTubeIcon from "./AddTestTube"

export { AddPersonIcon, AddSampleIcon, AddTestTubeIcon }

export interface IconComponent extends IconProps {}
