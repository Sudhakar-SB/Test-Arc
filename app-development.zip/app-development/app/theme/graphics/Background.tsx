import { Icon, IconProps } from "@chakra-ui/react"

const Background = ({ ...props }: IconProps) => (
  <Icon viewBox="0 0 1143 642" {...props} fill="none">
    <g clipPath="url(#clip0)">
      <path
        d="M1062.93 126.773C1075.57 126.773 1085.83 137.273 1085.83 150.206C1085.83 163.139 1075.57 173.64 1062.93 173.64C1050.29 173.64 1040.03 163.139 1040.03 150.206C1040.03 137.273 1050.29 126.773 1062.93 126.773Z"
        fill="#EBF8FF"
      />
      <path
        d="M1103.86 158.264C1208.38 187.361 1360.54 228.426 1348.27 721.391"
        stroke="#EBF8FF"
        strokeWidth="7.6371"
        strokeLinecap="round"
      />
      <path
        d="M665.7 812.835C665.7 812.835 668.432 543.75 668.118 506.883C666.511 318.889 800.752 142.566 1021.49 145.298"
        stroke="#EBF8FF"
        strokeWidth="7.6371"
        strokeLinecap="round"
      />
      <path
        d="M1015.16 278.947C1034.57 281.344 1193.6 286.785 1224.71 457.041C1226.05 464.411 1225.28 855.213 1227.88 856.122"
        stroke="#EBF8FF"
        strokeWidth="7.6371"
        strokeLinecap="round"
      />
      <path
        d="M794.536 874.076C794.536 874.076 794.417 492.111 794.84 490.322C799.948 442.688 815.536 358.108 924.336 301.641"
        stroke="#EBF8FF"
        strokeWidth="7.6371"
        strokeLinecap="round"
      />
      <path
        d="M919.056 608.549C919.056 608.549 917.977 516.965 921.425 516.455C932.244 394.849 1105.95 409.17 1109.87 518.959C1111.23 521.288 1111.33 822.464 1110.66 830.187"
        stroke="#EBF8FF"
        strokeWidth="7.6371"
        strokeLinecap="round"
      />
      <path
        d="M1103.86 158.264C1208.38 187.361 1360.54 228.426 1348.27 721.391"
        stroke="#EBF8FF"
        strokeWidth="20"
        strokeLinecap="round"
      />
      <path
        d="M665.7 812.835C665.7 812.835 668.432 543.75 668.118 506.883C666.511 318.889 800.752 142.566 1021.49 145.298"
        stroke="#EBF8FF"
        strokeWidth="20"
        strokeLinecap="round"
      />
      <path
        d="M1015.16 278.947C1034.57 281.344 1193.6 286.785 1224.71 457.041C1226.05 464.411 1225.28 855.213 1227.88 856.122"
        stroke="#EBF8FF"
        strokeWidth="20"
        strokeLinecap="round"
      />
      <path
        d="M794.536 874.076C794.536 874.076 794.417 492.111 794.84 490.322C799.948 442.688 815.536 358.108 924.336 301.641"
        stroke="#EBF8FF"
        strokeWidth="20"
        strokeLinecap="round"
      />
      <path
        d="M919.056 608.549C919.056 608.549 917.977 516.965 921.425 516.455C932.244 394.849 1105.95 409.17 1109.87 518.959C1111.23 521.288 1111.33 822.464 1110.66 830.187"
        stroke="#EBF8FF"
        strokeWidth="20"
        strokeLinecap="round"
      />
      <path
        d="M-45 186.908C114.457 213.846 215.372 35.4825 218.295 -20"
        stroke="#EBF8FF"
        strokeWidth="20"
        strokeLinecap="round"
      />
    </g>
    <defs>
      <clipPath id="clip0">
        <rect width="1321" height="751" fill="white" transform="translate(-178)" />
      </clipPath>
    </defs>
  </Icon>
)

export default Background
