// Tips for generating your own icons
// https://chakra-ui.com/docs/components/icon#tips-for-generating-your-own-icons
import { IconProps } from "@chakra-ui/react"
import BackgroundGraphic from "./Background"
import EmblemGraphic from "./Emblem"

export { EmblemGraphic, BackgroundGraphic }

export interface Graphic extends IconProps {}
