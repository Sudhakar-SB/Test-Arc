import { resolver } from "blitz"
import db from "db"

export default resolver.pipe(resolver.authorize(), async (_, ctx) => {
  const { userId } = ctx.session

  const subjects = db.subject.findMany({ where: { userId } })

  return subjects
})
