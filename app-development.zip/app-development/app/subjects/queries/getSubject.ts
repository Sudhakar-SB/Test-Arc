import { resolver } from "blitz"
import * as z from "zod"
import authorizeSubjectAccess from "../../security/authorization/authorizeSubjectAccess"

const GetSubject = z.object({
  id: z.string(),
})

export default resolver.pipe(
  resolver.zod(GetSubject),
  resolver.authorize(),
  async ({ id }, ctx) => {
    const subject = await authorizeSubjectAccess(id, ctx)
    // TODO: in multi-tenant app, you must add validation to ensure correct tenant

    return subject
  }
)
