import { Button } from "@chakra-ui/button"
import { Flex, SimpleGrid } from "@chakra-ui/layout"
import DateField from "app/core/components/DateField"
import Form, { FORM_ERROR } from "app/core/components/Form"
import SelectField from "app/core/components/SelectField"
import TextField from "app/core/components/TextField"
import updateSubjectPersonalInfo from "app/subjects/mutations/updateSubjectPersonalInfo"
import { FamilyHistory, OnSubmit, PersonalInfo } from "app/subjects/validations"
import { Routes, useMutation, useRouter } from "blitz"
import { Gender, SubjectStatus } from "db"
import _ from "lodash"
import moment from "moment"
import { FC } from "react"
import { FormRenderProps } from "react-final-form"
import RadioField from "../../core/components/RadioField"
import { BoxIdInvalidError } from "../../security/authorization/authorizeBoxId"
import { useSubjectContext } from "../utils/SubjectContext"
import validateSubject from "../utils/validateSubject"

const PersonalInfoForm: FC = () => {
  const router = useRouter()
  const { subject, setSubject } = useSubjectContext()
  const [updateSubject] = useMutation(updateSubjectPersonalInfo)
  const initialValues = _.omitBy(_.pick(subject, _.keys(PersonalInfo.shape)), _.isNull)
  initialValues.familyMember = initialValues.familyMember?.toString()

  if (!subject) {
    return null
  }

  const formDisabled = subject.status === SubjectStatus.Submitted
  const isNextStepValid = validateSubject(subject, FamilyHistory)

  return (
    <Form
      keepDirtyOnReinitialize={true}
      schema={PersonalInfo.merge(OnSubmit)}
      initialValues={initialValues}
      onSubmit={async ({ onSubmit, ...values }) => {
        try {
          if (!formDisabled) {
            const updated = await updateSubject(values)
            setSubject(updated)
          }
          onSubmit && onSubmit()
        } catch (error) {
          if (error instanceof BoxIdInvalidError) {
            return { boxId: "This is either not a valid box ID or it has been used already." }
          } else {
            return { [FORM_ERROR]: error.toString() }
          }
        }
      }}
    >
      {({ submitting, form }: FormRenderProps) => {
        return (
          <>
            <SimpleGrid columns={2} spacing={6}>
              <TextField
                name="boxId"
                label="Box ID"
                helperText="Enter the ID found on the box, it looks like ar000000000"
                placeholder="ar000000000"
                isRequired
                isDisabled={formDisabled}
              />
              <DateField
                name="sampleCollectionDate"
                label="Date of sample collection"
                placeholder="DD.MM.YYYY"
                isRequired
                isDisabled={formDisabled}
                minDate={new Date()}
                maxDate={moment(new Date()).add(30, "d").toDate()}
                onChangeRaw={(e) => e.preventDefault()}
              />
            </SimpleGrid>

            <RadioField
              name="familyMember"
              stackDirection="column"
              options={[
                {
                  label: "This information is about me or an immediate family member",
                  value: "true",
                },
                {
                  label:
                    "This information is for a disabled person who I am legally taking care of",
                  value: "false",
                },
              ]}
              isRequired
              isDisabled={formDisabled}
            />

            <SimpleGrid columns={2} spacing={6}>
              <TextField
                name="firstName"
                label="First name"
                placeholder="John"
                isRequired
                isDisabled={formDisabled}
              />
              <TextField
                name="lastName"
                label="Last name"
                placeholder="Doe"
                isRequired
                isDisabled={formDisabled}
              />
            </SimpleGrid>

            <SimpleGrid columns={2} spacing={6}>
              <SelectField
                name="gender"
                label="Gender"
                placeholder="Select"
                isRequired
                options={Object.values(Gender).map((value) => ({ label: value, value }))}
                isDisabled={formDisabled}
              />
              <DateField
                name="birthDate"
                label="Date of birth"
                placeholder="DD.MM.YYYY"
                dropdownMode="select"
                showMonthDropdown
                showYearDropdown
                isRequired
                maxDate={new Date()}
                isDisabled={formDisabled}
                onChangeRaw={(e) => e.preventDefault()}
              />
            </SimpleGrid>

            <TextField
              name="addressLine1"
              label="Address"
              placeholder="Germanistr. 1 A"
              isDisabled={formDisabled}
              isRequired
            />

            <SimpleGrid columns={2} spacing={6}>
              <TextField
                name="addressCity"
                label="City"
                placeholder="Berlin"
                isDisabled={formDisabled}
                isRequired
              />
              <TextField
                name="addressPostCode"
                label="Postcode"
                placeholder="12099"
                isDisabled={formDisabled}
                isRequired
              />
            </SimpleGrid>

            <SimpleGrid columns={2} spacing={6}>
              <TextField
                name="addressCountry"
                label="Country"
                placeholder="Germany"
                isDisabled={formDisabled}
                isRequired
              />
            </SimpleGrid>

            <Flex alignItems="center" mt={10}>
              <Button
                type="button"
                mr="auto"
                colorScheme="expertBlue"
                variant="outline"
                onClick={() => {
                  router.push(Routes.SubjectsPage())
                }}
              >
                Back
              </Button>

              <Button
                ml="auto"
                type="submit"
                colorScheme="expertBlue"
                variant={isNextStepValid ? "link" : "solid"}
                isLoading={submitting}
                onClick={() => {
                  form.change("onSubmit", () =>
                    router.push(Routes.SubjectFamilyHistory({ subjectId: subject.id }))
                  )
                }}
              >
                Next
              </Button>

              {isNextStepValid && (
                <Button
                  ml={4}
                  type="submit"
                  colorScheme="expertBlue"
                  isLoading={submitting}
                  onClick={() => {
                    form.change("onSubmit", () =>
                      router.push(Routes.SubjectSummary({ subjectId: subject.id }))
                    )
                  }}
                >
                  Summary
                </Button>
              )}
            </Flex>
          </>
        )
      }}
    </Form>
  )
}

export default PersonalInfoForm
