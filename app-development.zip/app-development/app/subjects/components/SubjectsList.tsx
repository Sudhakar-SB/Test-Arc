import {
  Box,
  Flex,
  Heading,
  HStack,
  LinkBox,
  LinkOverlay,
  SimpleGrid,
  Text,
} from "@chakra-ui/layout"
import {
  Avatar,
  Icon,
  IconButton,
  Menu,
  MenuButton,
  MenuItem,
  MenuList,
  Skeleton,
  SkeletonCircle,
  Tag,
} from "@chakra-ui/react"
import ConfirmDialog from "app/core/components/ConfirmDialog"
import getUserSubjects from "app/subjects/queries/getUserSubjects"
import { Link as BlitzLink, Routes, useMutation, useQuery } from "blitz"
import { Subject, SubjectStatus } from "db"
import moment from "moment"
import { FC } from "react"
import { BsThreeDotsVertical } from "react-icons/bs"
import deleteSubject from "../mutations/deleteSubject"

const SubjectsList: FC = () => {
  const [subjects, { refetch }] = useQuery(getUserSubjects, {})
  const [deleteSubjectMutation] = useMutation(deleteSubject)

  const handleSubjectDelete = async (id: Subject["id"]) => {
    await deleteSubjectMutation({ id })
    await refetch()
  }

  if (subjects.length === 0) {
    return <Text>No subjects registered yet.</Text>
  }

  return (
    <SimpleGrid columns={2} spacing={4}>
      {subjects.map((subject) => {
        const { id, firstName, lastName, paymentId, status, birthDate, gender } = subject
        const name = firstName && lastName ? `${firstName} ${lastName}` : undefined
        const age = moment().diff(birthDate, "years")
        return (
          <BlitzLink href={Routes.SubjectPersonalInfo({ subjectId: id })} key={id} passHref>
            <LinkBox
              background="gray.100"
              p={4}
              borderRadius="lg"
              display="flex"
              flexDirection="column"
              justifyContent="space-between"
              _hover={{ textDecoration: "none", boxShadow: "md" }}
              cursor="pointer"
            >
              <Flex alignItems="flex-start" justifyContent="space-between">
                <HStack spacing={4} alignItems="flex-start">
                  <Avatar size="sm" name={name} background="gray.300" />
                  <Box>
                    {name && <Heading size="md">{name}</Heading>}
                    <Text color="gray.500" fontSize="sm">
                      {paymentId}
                    </Text>
                  </Box>
                </HStack>
                {status !== SubjectStatus.Submitted && (
                  <LinkOverlay>
                    <Menu placement="bottom-end">
                      <MenuButton
                        as={IconButton}
                        size="sm"
                        aria-label="more"
                        isRound
                        onClick={(e) => {
                          e.stopPropagation()
                        }}
                      >
                        <Icon as={BsThreeDotsVertical} />
                      </MenuButton>
                      <MenuList>
                        <ConfirmDialog
                          onTriggerClick={(e) => e.stopPropagation()}
                          trigger={(props) => <MenuItem {...props}>Delete</MenuItem>}
                          onConfirm={() => handleSubjectDelete(id)}
                          body={`Are you sure you want to delete the subject ${
                            name || `with Payment ID "${paymentId}"`
                          }?`}
                          ctaText="Delete"
                        />
                      </MenuList>
                    </Menu>
                  </LinkOverlay>
                )}
              </Flex>
              <Flex alignItems="flex-end" justifyContent="space-between" mt={6}>
                {gender && <Text>{gender}</Text>}
                {status === SubjectStatus.Draft ? (
                  <Tag colorScheme="orange" ml="auto" fontWeight="bold" textTransform="uppercase">
                    Draft
                  </Tag>
                ) : (
                  <Text>{age} years old</Text>
                )}
              </Flex>
            </LinkBox>
          </BlitzLink>
        )
      })}
    </SimpleGrid>
  )
}

export default SubjectsList

export const SubjectsListLoader: FC = () => {
  return (
    <SimpleGrid columns={2}>
      <Box
        background="gray.100"
        p={4}
        borderRadius="lg"
        display="flex"
        flexDirection="column"
        justifyContent="space-between"
      >
        <Flex alignItems="flex-start" justifyContent="space-between">
          <HStack spacing={4}>
            <SkeletonCircle size="32px" />
            <Box>
              <Skeleton height="20px" width="100px" mb={2} />
              <Skeleton height="14px" width="30px" />
            </Box>
          </HStack>
          <IconButton size="sm" aria-label="more" isRound isDisabled>
            <Icon as={BsThreeDotsVertical} />
          </IconButton>
        </Flex>
        <Flex alignItems="flex-end" justifyContent="space-between" mt={6}>
          <Skeleton height="14px" width="30px" />
          <Skeleton height="14px" width="90px" />
        </Flex>
      </Box>
    </SimpleGrid>
  )
}
