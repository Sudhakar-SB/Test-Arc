import { Alert, AlertIcon } from "@chakra-ui/alert"
import { Button } from "@chakra-ui/button"
import { Flex } from "@chakra-ui/layout"
import Documents from "app/subjects/components/Documents"
import SymptomFinder from "app/symptoms/components/SymptomFinder"
import { Routes, useMutation, useRouter } from "blitz"
import { SubjectStatus, Symptom } from "db"
import arrayMutators from "final-form-arrays"
import createDecorator from "final-form-calculate"
import _ from "lodash"
import { FC } from "react"
import { Form as FinalForm } from "react-final-form"
import updateSubjectClinicalInfo from "../mutations/updateSubjectClinicalInfo"
import { useSubjectContext } from "../utils/SubjectContext"
import { ClinicalInfo } from "../validations"
import SubjectSymptomFields from "./SubjectSymptomFields"

const decorator = createDecorator({
  field: "symptoms",
  updates: {
    hasSymptoms: (symptoms) => symptoms.length > 0,
  },
})

interface Props {}

const ClinicalInfoForm: FC<Props> = () => {
  const router = useRouter()
  const { subject, setSubject, refetchSubject } = useSubjectContext()
  const [updateSubject] = useMutation(updateSubjectClinicalInfo)

  if (!subject) {
    return null
  }

  const initialValues = _.pick(subject, _.keys(ClinicalInfo.shape))
  const formDisabled = subject.status === SubjectStatus.Submitted

  return (
    <FinalForm
      keepDirtyOnReinitialize={true}
      submitText="Next"
      mutators={{ ...arrayMutators }}
      decorators={[decorator]}
      initialValues={initialValues}
      validate={(values) => {
        try {
          ClinicalInfo.parse(values)
        } catch (error) {
          return error.formErrors.fieldErrors
        }
      }}
      onSubmit={async (values) => {
        if (!formDisabled) {
          const subject = await updateSubject(values)
          setSubject(subject)
        }
        router.push(Routes.SubjectSummary({ subjectId: subject.id }))
      }}
      render={({
        submitError,
        handleSubmit,
        submitting,
        form: {
          mutators: { push },
        },
        values,
      }) => {
        return (
          <Flex as="form" direction="column" onSubmit={handleSubmit}>
            {!formDisabled && (
              <SymptomFinder
                onSymptomClick={({ key }: Symptom) =>
                  push("symptoms", { symptomKey: key, ongoing: false })
                }
                selectedKeys={values.symptoms.map(({ symptomKey }) => symptomKey)}
              />
            )}

            <SubjectSymptomFields isDisabled={formDisabled} />

            <Documents
              subjectId={subject.id}
              subjectFiles={subject.files}
              refetchDocuments={() => refetchSubject()}
              isDisabled={formDisabled}
            />

            {submitError && (
              <Alert status="error" variant="solid" mt={8}>
                <AlertIcon />
                {submitError}
              </Alert>
            )}

            <Flex alignItems="center" mt={10}>
              <Button
                type="button"
                mr="auto"
                colorScheme="expertBlue"
                variant="outline"
                onClick={() =>
                  router.push(Routes.SubjectBodyMeasurements({ subjectId: subject.id }))
                }
              >
                Back
              </Button>

              <Button ml="auto" type="submit" colorScheme="expertBlue" isLoading={submitting}>
                Next
              </Button>
            </Flex>
          </Flex>
        )
      }}
    />
  )
}

export default ClinicalInfoForm
