import { DeleteIcon } from "@chakra-ui/icons"
import {
  Box,
  BoxProps,
  Button,
  Flex,
  Heading,
  IconButton,
  Text,
  useToast,
  VisuallyHidden,
} from "@chakra-ui/react"
import { SubjectFile } from "@prisma/client"
import { PresignedPost } from "aws-sdk/clients/s3"
import { useMutation } from "blitz"
import React, { ChangeEvent, useState } from "react"
import sanitize from "sanitize-s3-objectkey"
import { ALLOWED_FILE_TYPES } from "../constants"
import createSubjectFileAndUploadUrl from "../mutations/createSubjectFileAndUploadUrl"
import deleteSubjectFile from "../mutations/deleteSubjectFile"

type DocumentsProps = {
  subjectId: string
  subjectFiles?: SubjectFile[]
  refetchDocuments?: (args?: { force?: boolean }) => void
  isDisabled?: boolean
} & BoxProps

const Documents = ({
  subjectId,
  subjectFiles = [],
  refetchDocuments = (args) => null,
  isDisabled,
  ...props
}: DocumentsProps) => {
  const [createSubjectFileAndUploadUrlMutation] = useMutation(createSubjectFileAndUploadUrl)
  const [deleteSubjectFileMutation] = useMutation(deleteSubjectFile)

  const [uploadInProgress, setUploadInProgress] = useState(false)

  const toast = useToast()

  const uploadDocument = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files![0]
    const filename = encodeURIComponent(sanitize(file.name))
    let presignedPost: PresignedPost
    let subjectFile: SubjectFile

    try {
      const result = await createSubjectFileAndUploadUrlMutation({
        size: file.size,
        name: filename,
        type: file.type,
        subjectId,
      })

      presignedPost = result.presignedPost
      subjectFile = result.attachment
    } catch (error) {
      console.error("Failed creating subject file", error)
      const parsedError = JSON.parse(error.message)
      const description = parsedError[0].message || error.message
      toast({
        title: "Error uploading document",
        description,
        status: "error",
        duration: 9000,
        isClosable: true,
      })
      return
    }

    const { url, fields } = presignedPost
    const formData = new FormData()

    Object.entries({ ...fields, file }).forEach(([key, value]) => {
      formData.append(key, value)
    })

    const upload = await fetch(url, {
      method: "POST",
      body: formData,
    })

    if (upload.ok) {
      console.log("Uploaded successfully!", upload)
    } else {
      console.error("Failed upload to s3", upload)
      toast({
        title: "Error uploading document",
        description: upload.statusText,
        status: "error",
        duration: 9000,
        isClosable: true,
      })

      try {
        await deleteSubjectFileMutation({
          fileId: subjectFile.id,
          subjectId,
        })
      } catch (error) {
        console.error("Failed deleting subject file in cleanup", error)
        toast({
          title: "Error uploading document",
          description: `${error?.message ? error.message : error}`,
          status: "error",
          duration: 9000,
          isClosable: true,
        })
      }
    }
  }

  const deleteFile = async (file: SubjectFile) => {
    try {
      await deleteSubjectFileMutation({ fileId: file.id, subjectId })

      refetchDocuments({ force: true })
    } catch (error) {
      console.error("Failed deleting subject file", error)
      toast({
        title: "Error uploading document",
        description: `${error?.message ? error.message : error}`,
        status: "error",
        duration: 9000,
        isClosable: true,
      })
    }
  }

  return (
    <>
      <Heading size="md" mt={10}>
        Additional medical documents (.pdf, .jpeg, ...)
      </Heading>
      <Box background="gray.100" borderRadius="md" p={4} mt={4}>
        <Text color="gray.500" fontSize="sm">
          File name
        </Text>
        {subjectFiles.map((file) => (
          <Flex alignItems="center" justifyContent="space-between" key={file.id} mb={2}>
            <Text fontWeight="bold">{file.name}</Text>
            <IconButton
              aria-label="Delete document"
              variant="ghost"
              isRound
              colorScheme="gray"
              size="sm"
              _hover={{ background: "gray.300" }}
              onClick={() => deleteFile(file)}
              isDisabled={isDisabled}
            >
              <DeleteIcon />
            </IconButton>
          </Flex>
        ))}

        <Flex alignItems="center" mt={8} {...props}>
          <Text color="gray.500" mr={12}>
            Upload New File
          </Text>
          <Button
            as="label"
            htmlFor="file-upload"
            colorScheme="blue"
            variant="outline"
            cursor="pointer"
            isLoading={uploadInProgress}
            isDisabled={isDisabled}
          >
            Browse
          </Button>

          <VisuallyHidden>
            <input
              id="file-upload"
              style={{ width: "240px" }}
              disabled={isDisabled || uploadInProgress}
              onChange={async (e: ChangeEvent<HTMLInputElement>) => {
                setUploadInProgress(true)
                await uploadDocument(e)
                refetchDocuments()
                // @ts-ignore: valid way to reset the input afaik
                e.target.value = null
                setUploadInProgress(false)
              }}
              type="file"
              accept={ALLOWED_FILE_TYPES.join(",")}
            />
          </VisuallyHidden>
        </Flex>
      </Box>
    </>
  )
}

export default Documents
