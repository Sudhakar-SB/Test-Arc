import { Form, FORM_ERROR } from "app/core/components/Form"
import TextField from "app/core/components/TextField"
import { Routes, useMutation, useRouter } from "blitz"
import { FC } from "react"
import registerSubject from "../mutations/registerSubject"
import { RegisterSubject } from "../validations"
import { PaymentIdTakenError } from "../../security/authorization/authorizePaymentId"

interface Props {}

const RegisterSubjectForm: FC<Props> = () => {
  const router = useRouter()
  const [registerSubjectMutation] = useMutation(registerSubject)
  return (
    <Form
      schema={RegisterSubject}
      submitText="Register"
      onSubmit={async (values) => {
        try {
          const subject = await registerSubjectMutation(values)
          // TODO redirect to subject personal info page
          router.push(Routes.SubjectPersonalInfo({ subjectId: subject.id }))
        } catch (error) {
          if (error instanceof PaymentIdTakenError) {
            return { paymentId: `The Payment ID ${values.paymentId} been registered already` }
          } else {
            return {
              [FORM_ERROR]: error.toString(),
            }
          }
        }
      }}
      buttonProps={{ mr: 0 }}
    >
      <TextField
        name="paymentId"
        label="Payment ID"
        placeholder="ABC-123-452"
        helperText="The Payment ID is in the email confirmation of your order"
        autoComplete="off"
      />
    </Form>
  )
}

export default RegisterSubjectForm
