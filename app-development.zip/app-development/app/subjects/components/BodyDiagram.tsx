import { Button, Flex, Image } from "@chakra-ui/react"
import { FC, useState } from "react"

interface Props {}

const BodyDiagram: FC<Props> = () => {
  const [isBackVisible, setBackVisible] = useState(false)
  return (
    <Flex direction="column" alignItems="center" mb={6}>
      <Flex
        position="relative"
        borderRadius="md"
        border="1px solid"
        borderColor="gray.200"
        overflow="hidden"
      >
        <Image
          src="/images/body-diagram-front.png"
          alt="Body Diagram Front"
          maxW={["50%", null, null, null, "100%"]}
        />
        <Image
          src="/images/body-diagram-back.png"
          alt="Body Diagram Back"
          position={["relative", null, null, null, "absolute"]}
          inset={0}
          zIndex={isBackVisible ? 0 : -1}
          maxW={["50%", null, null, null, "100%"]}
        />
      </Flex>
      <Button
        size="sm"
        mt={4}
        onClick={() => setBackVisible((v) => !v)}
        display={["none", null, null, null, "inline-flex"]}
      >
        Show {isBackVisible ? "Front" : "Back"}
      </Button>
    </Flex>
  )
}

export default BodyDiagram
