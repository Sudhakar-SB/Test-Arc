import { DeleteIcon } from "@chakra-ui/icons"
import { Center, Grid, GridProps, IconButton, Skeleton, Text } from "@chakra-ui/react"
import CheckboxField from "app/core/components/CheckboxField"
import TextField from "app/core/components/TextField"
import SymptomName from "app/symptoms/components/SymptomName"
import { SubjectSymptom } from "db"
import { FC, Suspense } from "react"
import { useField } from "react-final-form"
import { useFieldArray } from "react-final-form-arrays"
import { SymptomNameLoader } from "../../symptoms/components/SymptomName"
import { ZSubjectSymptom } from "../validations"

interface FieldProps {
  name: string
  onDelete: () => void
  isDisabled?: boolean
}

const SubjectSymptomField: FC<FieldProps> = ({ name, onDelete, isDisabled }) => {
  const { input } = useField(name, {
    validate: (value) => {
      try {
        ZSubjectSymptom.parse(value)
      } catch (error) {
        return error.formErrors.fieldErrors
      }
    },
  })

  const { symptomKey, ongoing } = input.value as SubjectSymptom

  return (
    <>
      <Text flex="1" fontWeight="bold">
        <SymptomName symptomKey={symptomKey} />
      </Text>

      <TextField
        type="number"
        size="sm"
        outerProps={{ mt: 0 }}
        name={`${name}.beginYear`}
        placeholder="YYYY"
        isRequired
        isDisabled={isDisabled}
        errorAsTooltip
      />

      <CheckboxField name={`${name}.ongoing`} mt={0} defaultChecked={ongoing ?? false}>
        <Text fontSize="sm">Ongoing</Text>
      </CheckboxField>

      <div>
        <IconButton
          aria-label="Delete"
          onClick={onDelete}
          size="sm"
          isRound
          variant="ghost"
          _hover={{ background: "gray.300" }}
          isDisabled={isDisabled}
        >
          <DeleteIcon h={3} w={3} />
        </IconButton>
      </div>
    </>
  )
}

const SubjectSymptomFieldLoader = () => {
  return (
    <>
      <SymptomNameLoader />
      <Skeleton height="40px" />
      <Skeleton height="40px" />
      <Center>
        <Skeleton height="20px" width="20px" />
      </Center>
    </>
  )
}

interface Props extends GridProps {
  isDisabled?: boolean
}

const SubjectSymptomFields: FC<Props> = ({ isDisabled, ...restProps }) => {
  const { fields } = useFieldArray("symptoms")

  return (
    <Grid
      templateColumns={`calc(100% - ${60 + 85 + 32 + 20 * 3}px) 60px 85px 32px`}
      autoFlow="row"
      alignItems="center"
      gap="20px"
      background="gray.100"
      borderRadius="md"
      p={4}
      mt={8}
      maxW="100%"
      {...restProps}
    >
      {fields.length === 0 ? (
        <Text textAlign="center" gridColumn="1/5" px={10} py={6}>
          Select your symptoms from the list above.
          <br />
          If you do not have any symptoms, click next below.
        </Text>
      ) : (
        <>
          <Text color="gray.500" fontSize="sm">
            Symptom
          </Text>
          <Text color="gray.500" fontSize="sm">
            Began
            <Text as="span" display="inline" color="red.600">
              *
            </Text>
          </Text>
          <Text color="gray.500" fontSize="sm">
            Ongoing
          </Text>
          <Text>&nbsp;</Text>
          {fields.map((name, index) => {
            return (
              <Suspense fallback={<SubjectSymptomFieldLoader />} key={`${fields.length}-${name}`}>
                <SubjectSymptomField
                  name={name}
                  onDelete={() => fields.remove(index)}
                  isDisabled={isDisabled}
                />
              </Suspense>
            )
          })}
        </>
      )}
    </Grid>
  )
}

export default SubjectSymptomFields
