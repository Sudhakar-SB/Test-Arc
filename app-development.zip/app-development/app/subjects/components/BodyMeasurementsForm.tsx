import { Button, Flex } from "@chakra-ui/react"
import { Form } from "app/core/components/Form"
import TextField from "app/core/components/TextField"
import { Routes, useMutation, useRouter } from "blitz"
import { Subject, SubjectStatus } from "db"
import _ from "lodash"
import { FC } from "react"
import { FormRenderProps } from "react-final-form"
import updateSubjectBodyMeasurements from "../mutations/updateSubjectBodyMeasurements"
import { useSubjectContext } from "../utils/SubjectContext"
import validateSubject from "../utils/validateSubject"
import { BodyMeasurements, ClinicalInfo, OnSubmit } from "../validations"

export const getInitialValues = (subject: Subject) => {
  const values = _.omitBy(_.pick(subject, _.keys(BodyMeasurements.shape)), _.isNull)
  const { id, userId, ...decimalValues } = values
  return { id, userId, ..._.mapValues(decimalValues, Number) }
}

interface Props {}

const BodyMeasurementsForm: FC<Props> = () => {
  const router = useRouter()
  const { subject, setSubject } = useSubjectContext()
  const [updateSubject] = useMutation(updateSubjectBodyMeasurements)

  if (!subject) {
    return null
  }

  const formDisabled = subject.status === SubjectStatus.Submitted

  const initialValues = getInitialValues(subject)
  const isNextStepValid = validateSubject(subject, ClinicalInfo)

  return (
    <Form
      keepDirtyOnReinitialize={true}
      schema={BodyMeasurements.merge(OnSubmit)}
      initialValues={initialValues}
      onSubmit={async ({ onSubmit, ...values }) => {
        if (!formDisabled) {
          const subject = await updateSubject(values)
          setSubject(subject)
        }
        onSubmit && onSubmit()
      }}
    >
      {({ submitting, form }: FormRenderProps) => {
        return (
          <>
            <TextField
              type="number"
              min={1}
              label="Body height in cm"
              placeholder="e.g., 180"
              name="height"
              isRequired
              isDisabled={formDisabled}
            />
            <TextField
              type="number"
              min={1}
              label="Body weight in kg"
              placeholder="e.g., 80"
              name="weight"
              isRequired
              isDisabled={formDisabled}
            />

            <Flex alignItems="center" mt={10}>
              <Button
                type="button"
                mr="auto"
                colorScheme="expertBlue"
                variant="outline"
                onClick={() => {
                  router.push(Routes.SubjectFamilyHistory({ subjectId: subject.id }))
                }}
              >
                Back
              </Button>

              <Button
                type="submit"
                ml="auto"
                colorScheme="expertBlue"
                variant={isNextStepValid ? "link" : "solid"}
                isLoading={submitting}
                onClick={() => {
                  form.change("onSubmit", () =>
                    router.push(Routes.SubjectClinicalInfo({ subjectId: subject.id }))
                  )
                }}
              >
                Next
              </Button>

              {isNextStepValid && (
                <Button
                  type="submit"
                  ml={4}
                  colorScheme="expertBlue"
                  isLoading={submitting}
                  onClick={() => {
                    form.change("onSubmit", () =>
                      router.push(Routes.SubjectSummary({ subjectId: subject.id }))
                    )
                  }}
                >
                  Summary
                </Button>
              )}
            </Flex>
          </>
        )
      }}
    </Form>
  )
}

export default BodyMeasurementsForm
