import { Button, Flex, Text } from "@chakra-ui/react"
import Form from "app/core/components/Form"
import RadioField from "app/core/components/RadioField"
import { Routes, useMutation, useRouter } from "blitz"
import { SubjectStatus, YesNoUnknown } from "db"
import { Mutator } from "final-form"
import _ from "lodash"
import { FC } from "react"
import { FormRenderProps } from "react-final-form"
import { familyHistoryFields } from "../constants"
import updateSubjectFamilyHistory from "../mutations/updateSubjectFamilyHistory"
import { useSubjectContext } from "../utils/SubjectContext"
import validateSubject from "../utils/validateSubject"
import { BodyMeasurements, FamilyHistory, OnSubmit } from "../validations"
import { getInitialValues as getMeasurementValues } from "./BodyMeasurementsForm"

const setNoToAllFields: Mutator = (e, formState, { changeValue }) => {
  Object.values(formState.fields).forEach((field) => {
    field.change(YesNoUnknown.No)
  })
}

interface Props {}

const FamilyHistoryForm: FC<Props> = () => {
  const router = useRouter()
  const { subject, setSubject } = useSubjectContext()
  const [updateSubject] = useMutation(updateSubjectFamilyHistory)
  const initialValues = _.omitBy(_.pick(subject, _.keys(FamilyHistory.shape)), _.isNull)

  if (!subject) {
    return null
  }

  const formDisabled = subject.status === SubjectStatus.Submitted
  const isNextStepValid = validateSubject(getMeasurementValues(subject), BodyMeasurements)

  return (
    <Form
      keepDirtyOnReinitialize={true}
      mutators={{ setNoToAllFields }}
      schema={FamilyHistory.merge(OnSubmit)}
      initialValues={initialValues}
      onSubmit={async ({ onSubmit, ...values }) => {
        if (!formDisabled) {
          const subject = await updateSubject(values)
          setSubject(subject)
        }
        onSubmit && onSubmit()
      }}
    >
      {({ form, submitting }: FormRenderProps) => {
        return (
          <>
            <Text mt={8}>
              Do you (or the subject who you are legal guardian to) have a family history of any of
              the following:
            </Text>

            <Flex mt={4} justifyContent="flex-end">
              <Button size="sm" onClick={form.mutators.setNoToAllFields}>
                Select No for all
              </Button>
            </Flex>

            {_.keys(familyHistoryFields).map((key) => {
              const { label } = familyHistoryFields[key]
              return (
                <RadioField
                  key={key}
                  name={key}
                  label={label}
                  options={Object.values(YesNoUnknown).map((value) => ({ label: value, value }))}
                  isRequired
                  isDisabled={formDisabled}
                />
              )
            })}

            <Flex alignItems="center" mt={10}>
              <Button
                type="button"
                mr="auto"
                colorScheme="expertBlue"
                variant="outline"
                onClick={() => {
                  router.push(Routes.SubjectPersonalInfo({ subjectId: subject.id }))
                }}
              >
                Back
              </Button>

              <Button
                type="submit"
                ml="auto"
                colorScheme="expertBlue"
                variant={isNextStepValid ? "link" : "solid"}
                isLoading={submitting}
                onClick={() => {
                  form.change("onSubmit", () =>
                    router.push(Routes.SubjectBodyMeasurements({ subjectId: subject.id }))
                  )
                }}
              >
                Next
              </Button>

              {isNextStepValid && (
                <Button
                  type="submit"
                  ml={4}
                  colorScheme="expertBlue"
                  isLoading={submitting}
                  onClick={() => {
                    form.change("onSubmit", () =>
                      router.push(Routes.SubjectSummary({ subjectId: subject.id }))
                    )
                  }}
                >
                  Summary
                </Button>
              )}
            </Flex>
          </>
        )
      }}
    </Form>
  )
}

export default FamilyHistoryForm
