import { Box, Flex, Heading, Link, ListItem, Text, UnorderedList } from "@chakra-ui/layout"
import SymptomName, { SymptomNameLoader } from "app/symptoms/components/SymptomName"
import { Link as BlitzLink, Routes, useRouter } from "blitz"
import moment from "moment"
import React, { FC, Suspense } from "react"
import getFamilyHistorySummary from "../utils/getFamilyHistorySummary"
import getSubjectAddress from "../utils/getSubjectAddress"
import { useSubjectContext } from "../utils/SubjectContext"

interface Props {}

const SummaryBox: FC<Props> = () => {
  const router = useRouter()
  const { subject } = useSubjectContext()
  if (!subject) {
    return null
  }

  const { firstName, lastName, gender, birthDate, height, weight, symptoms, files } = subject
  const address = getSubjectAddress(subject)
  const familyHistorySummary = getFamilyHistorySummary(subject)
  const isRTL = router.locale === "ar"

  return (
    <Box background="gray.100" borderRadius="md" py={6} px={6} mt={8}>
      <Flex alignItems="center" justifyContent="space-between" mb={2}>
        <Heading size="sm">Personal Information</Heading>
        <BlitzLink href={Routes.SubjectPersonalInfo({ subjectId: subject.id })} passHref>
          <Link fontSize="sm" color="blue.500">
            Edit
          </Link>
        </BlitzLink>
      </Flex>
      <Text>
        {firstName} {lastName}
      </Text>
      <Text>
        {gender} born {moment(birthDate).format("DD.MM.YYYY")}
      </Text>
      {address && <Text>{address}</Text>}

      <Flex alignItems="center" justifyContent="space-between" mt={6} mb={2}>
        <Heading size="sm">Family History</Heading>
        <BlitzLink href={Routes.SubjectFamilyHistory({ subjectId: subject.id })} passHref>
          <Link fontSize="sm" color="blue.500">
            Edit
          </Link>
        </BlitzLink>
      </Flex>
      <Text>{familyHistorySummary}</Text>

      <Flex alignItems="center" justifyContent="space-between" mt={6} mb={2}>
        <Heading size="sm">Physical Information</Heading>
        <BlitzLink href={Routes.SubjectBodyMeasurements({ subjectId: subject.id })} passHref>
          <Link fontSize="sm" color="blue.500">
            Edit
          </Link>
        </BlitzLink>
      </Flex>
      <Text>
        Body height {height} cm, Body weight {weight} kg
      </Text>

      <Flex alignItems="center" justifyContent="space-between" mt={6} mb={2}>
        <Heading size="sm">Clinical Info</Heading>
        <BlitzLink href={Routes.SubjectClinicalInfo({ subjectId: subject.id })} passHref>
          <Link fontSize="sm" color="blue.500">
            Edit
          </Link>
        </BlitzLink>
      </Flex>

      {symptoms.length === 0 ? (
        <Text>No symptoms specified.</Text>
      ) : (
        <UnorderedList style={{ direction: isRTL ? "rtl" : "ltr" }}>
          {symptoms.map(({ id, symptomKey, beginYear, ongoing }) => (
            <ListItem key={id}>
              <Suspense fallback={<SymptomNameLoader />}>
                <SymptomName symptomKey={symptomKey} display="inline" />
              </Suspense>
              : {beginYear}
              {ongoing ? `-ongoing` : ""}
            </ListItem>
          ))}
        </UnorderedList>
      )}

      <Heading size="sm" mt={6} mb={2}>
        Additional medical documents
      </Heading>

      {files.length === 0 ? (
        <Text>No documents attached.</Text>
      ) : (
        <UnorderedList>
          {files.map(({ id, name }) => (
            <ListItem key={id}>{name}</ListItem>
          ))}
        </UnorderedList>
      )}
    </Box>
  )
}

export default SummaryBox
