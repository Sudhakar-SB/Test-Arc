import { ExternalLinkIcon } from "@chakra-ui/icons"
import { Link } from "@chakra-ui/layout"
import { useToast } from "@chakra-ui/toast"
import CheckboxField from "app/core/components/CheckboxField"
import Form from "app/core/components/Form"
import RadioField from "app/core/components/RadioField"
import { BadGatewayError } from "app/core/utils/errors"
import { Routes, useMutation, useRouter } from "blitz"
import { SubjectStatus } from "db"
import _ from "lodash"
import { FC } from "react"
import { CONSENT_FORM_LINKS, yesNoOptions } from "../constants"
import { useSubjectContext } from "../utils/SubjectContext"
import { Consents } from "../validations"
import submitSubject from "../mutations/submitSubject"

interface Props {}

const ConsentForm: FC<Props> = () => {
  const router = useRouter()
  const toast = useToast()
  const { subject, setSubject } = useSubjectContext()
  const [updateSubject] = useMutation(submitSubject)

  if (!subject) {
    return null
  }

  const values = _.omitBy(_.pick(subject, _.keys(Consents.shape)), _.isNull)
  const { id, userId, formConsent, ...yesNoValues } = values
  const initialValues = {
    id,
    userId,
    formConsent,
    ..._.mapValues(yesNoValues, (bool) => bool.toString()),
  }
  const formDisabled = subject.status === SubjectStatus.Submitted

  return (
    <Form
      keepDirtyOnReinitialize={true}
      submitText="Submit"
      buttonProps={{ isDisabled: formDisabled }}
      backText="Back"
      onBack={() => {
        router.push(Routes.SubjectClinicalInfo({ subjectId: subject.id }))
      }}
      schema={Consents}
      initialValues={initialValues}
      onSubmit={async (values) => {
        if (!formDisabled) {
          try {
            const subject = await updateSubject(values)
            setSubject(subject)
            toast({
              status: "success",
              title: "Successful!",
              description: `Subject "${subject.firstName} ${subject.lastName}" has been submitted successfully.`,
            })
            router.push(Routes.Dashboard())
          } catch (e) {
            // weird quirk: custom errors need to be caught
            // in frontend to avoid unknown class error
            // https://gitlab.com/arcensus/app/-/merge_requests/12#note_593081475
            if (e instanceof BadGatewayError) {
              console.error(e)
            } else {
              console.error(e)
            }
          }
        }
      }}
    >
      <CheckboxField
        name="formConsent"
        helperText={
          <>
            {CONSENT_FORM_LINKS.map(({ label, href }) => {
              return (
                <Link
                  isExternal
                  key={href}
                  href={href}
                  display="inline-flex"
                  alignItems="center"
                  color="blue.500"
                  mr={2}
                >
                  {label}
                  <ExternalLinkIcon mx={1} mb={1} />
                </Link>
              )
            })}
          </>
        }
        defaultChecked={formConsent}
        isRequired
        isDisabled={formDisabled}
      >
        I have read and agreed to the consent form
      </CheckboxField>

      <RadioField
        name="researchConsent"
        label="I consent to the use of my swab sample, derived genomic data, health, and
        genomic data by arcensus in pseudonymized form - for statistical analyses,
        publications, and further scientific (including commercial) research, which
        focuses on the cause, early detection and/or treatment of genetic diseases in
        general. For that purposes my pseudonymized data might be shared with
        external scientific institutions and/or (pharmaceutical) companies that maintain data protection standards comparable to the GDPR for their own
        scientific (including commercial) research (voluntary)"
        options={yesNoOptions}
        isRequired
        defaultValue={initialValues["researchConsent"]}
        isDisabled={formDisabled}
      />

      <RadioField
        name="incidentalFindingsConsent"
        label="I would like my incidental finding(s) to be reported via a medical report (voluntary)"
        options={yesNoOptions}
        isRequired
        defaultValue={initialValues["incidentalFindingsConsent"]}
        isDisabled={formDisabled}
      />
    </Form>
  )
}

export default ConsentForm
