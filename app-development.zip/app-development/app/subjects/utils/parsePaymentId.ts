export enum PaymentIdType {
  ARCENSUS,
  AMAZON,
  OTHER,
}

export enum PaymentIdFormat {
  VALID_FORMAT,
  INVALID_FORMAT,
}

export function parsePaymentId(paymentId: string): [PaymentIdType, PaymentIdFormat] {
  const start = paymentId.substr(0, 3)

  if (start === "DNA") {
    return [
      PaymentIdType.ARCENSUS,
      paymentId.match(/^DNA-[a-z0-9]{10}$/)
        ? PaymentIdFormat.VALID_FORMAT
        : PaymentIdFormat.INVALID_FORMAT,
    ]
  } else if (start.match(/^\d{3}$/)) {
    return [
      PaymentIdType.AMAZON,
      paymentId.match(/^\d{3}-\d{7}-\d{7}$/)
        ? PaymentIdFormat.VALID_FORMAT
        : PaymentIdFormat.INVALID_FORMAT,
    ]
  }

  return [PaymentIdType.OTHER, PaymentIdFormat.INVALID_FORMAT]
}
