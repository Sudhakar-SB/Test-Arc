import { Subject } from "@prisma/client"
import _ from "lodash"
import { addressKeys } from "../constants"

const getSubjectAddress = (subject: Subject): string | undefined => {
  const addressValues = _.values(_.pick(subject, addressKeys))
  if (_.reject(addressValues, (val) => !val).length === 0) {
    return undefined
  }
  return addressValues.join(", ")
}

export default getSubjectAddress
