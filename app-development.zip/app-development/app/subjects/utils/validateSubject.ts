import _ from "lodash"
import { ZodObject } from "zod"

// subject needs any type since some fields are parsed as per usage
const validateSubject = (subject: any, schema: ZodObject<{}>) => {
  if (subject && (subject.familyMember === true || subject.familyMember === false)) {
    subject = { ...subject, familyMember: subject.familyMember.toString() }
  }

  return schema.safeParse(_.pick(subject, _.keys(schema.shape))).success
}

export default validateSubject
