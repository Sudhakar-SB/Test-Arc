import { File, Subject } from "@prisma/client"

/**
 * Forms the url to an SubjectFile.
 *
 * @param file SubjectFile
 */
export const fileToUrl = (file: File): string => {
  const bucketName = process.env.NEXT_PUBLIC_BUCKET_NAME

  const s3Key = buildS3Key(file.subjectId!, file.id, file.name)

  const baseBucketUrl = `https://${bucketName}.s3.amazonaws.com`

  return `${baseBucketUrl}/${s3Key}`
}

/**
 * Builds the s3 key, i.e. full path to the file in s3
 */
export const buildS3Key = (
  subjectId: Subject["id"],
  fileId: File["id"],
  filename: File["name"]
): string => {
  return `subjects/${subjectId}/documents/${fileId}/${fileId}_${filename}`
}
