import { Subject, SubjectFile, SubjectSymptom } from "@prisma/client"
import { createContext, useContext } from "react"

interface SubjectWithRelations extends Subject {
  symptoms: SubjectSymptom[]
  files: SubjectFile[]
}

interface SubjectContextType {
  subject?: SubjectWithRelations
  setSubject: (symptom: SubjectWithRelations) => void
  refetchSubject: () => void
}

export const defaultSubjectContext: SubjectContextType = {
  subject: undefined,
  setSubject: () => {},
  refetchSubject: () => {},
}

export const SubjectContext = createContext<SubjectContextType>(defaultSubjectContext)

export const useSubjectContext = () => {
  return useContext(SubjectContext)
}
