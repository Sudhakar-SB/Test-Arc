import { Subject, YesNoUnknown } from "@prisma/client"
import _ from "lodash"
import { familyHistoryFields } from "../constants"

const getFamilyHistorySummary = (subject: Subject): string => {
  const trueFamilyHistoryFields = _.pickBy(
    _.pick(subject, _.keys(familyHistoryFields)),
    (val) => val === YesNoUnknown.Yes
  )

  if (_.keys(trueFamilyHistoryFields).length > 0) {
    const trueFields = _.pick(familyHistoryFields, _.keys(trueFamilyHistoryFields))

    return _.values(_.mapValues(trueFields, "summary")).join(", ")
  }

  return "No family history specified."
}

export default getFamilyHistorySummary
