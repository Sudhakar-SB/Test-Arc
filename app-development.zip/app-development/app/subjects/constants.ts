export const yesNoOptions = [
  { label: "Yes", value: "true" },
  { label: "No", value: "false" },
]

export const addressKeys = ["addressLine1", "addressCity", "addressPostCode", "addressCountry"]

export const familyHistoryFields = {
  cancer: {
    label: "Have or had any form of cancer?",
    summary: "Cancer",
  },

  unexplainedDeath: {
    label: "Had an unexplained death before the age of 30 years?",
    summary: "Unexplained death before 30",
  },

  longTermTreatment: {
    label: "Have or had any long-term or frequent treatment in a hospital?",
    summary: "Long term treatment in hospital",
  },

  mentalHealthIssues: {
    label: "Have or had any mental health problems?",
    summary: "Mental health issues / cognitive decline",
  },

  heartProblems: {
    label: "Have or had any heart problems before the age of 40 years?",
    summary: "Heart problems before 40",
  },

  organTransplantation: {
    label: "Had  an organ transplantation?",
    summary: "Organ transplantation",
  },

  visionLoss: {
    label: "Had blindness?",
    summary: "Vision loss",
  },

  hearingLoss: {
    label: "Had deafness?",
    summary: "Deafness",
  },

  stroke: {
    label: "Had a stroke?",
    summary: "Stroke",
  },

  miscarriage: {
    label: "Have female family member(s) had a miscarriage and/or stillbirth?",
    summary: "Miscarriage",
  },
}

export const ALLOWED_FILE_TYPES = ["application/pdf", "image/png", "image/jpg", "image/jpeg"]

export const CONSENT_FORM_LINKS = [
  { label: "English", href: "/documents/Consent_EN_20210516_V6.0_VSK.pdf" },
  { label: "Spanish", href: "/documents/Consent_ES_20210516_V6.0_VSK.pdf" },
  { label: "Arabic", href: "/documents/Consent_Arabic_20210516_V6.0_VSK.pdf" },
]
