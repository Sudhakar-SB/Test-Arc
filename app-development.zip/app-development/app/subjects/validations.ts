import { Gender, YesNoUnknown } from "db"
import * as z from "zod"
import { parsePaymentId, PaymentIdFormat, PaymentIdType } from "./utils/parsePaymentId"

const customErrorMap: z.ZodErrorMap = (issue, ctx) => {
  if (issue.code === z.ZodIssueCode.invalid_enum_value) {
    return { message: "Required" }
  }
  return { message: ctx.defaultError }
}

z.setErrorMap(customErrorMap)

export const booleanString = z.union([z.literal("true"), z.literal("false")])

export const RegisterSubject = z.object({
  paymentId: z.string().superRefine((paymentId, ctx) => {
    const [type, format] = parsePaymentId(paymentId)

    if (format === PaymentIdFormat.VALID_FORMAT) {
      return
    }

    if (type === PaymentIdType.ARCENSUS) {
      return ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: `This looks like an arcensus shop order. The input "DNA" should be followed by "-" and then exactly ten lowercase digits or numbers. Example: DNA-ei32fn328d.`,
      })
    } else if (type === PaymentIdType.AMAZON) {
      return ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: `This looks like an amazon order. It should consist of three digits, followed by seven digits, again followed by seven digits, separated by dashes. Example: 306-4025808-2485922.`,
      })
    } else {
      return ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: `Payment ids start with "DNA" (for arcensus shop orders) or with three digits (for amazon orders).`,
      })
    }
  }),
})

const common = {
  id: z.string(),
  userId: z.string(),
}

export const PersonalInfo = z.object({
  ...common,
  boxId: z.string().refine((boxId) => boxId.match(/ar\d{9}/), {
    message: `The box ID consists of "ar" followed by nine digits`,
  }),
  sampleCollectionDate: z.date(),
  familyMember: booleanString,
  firstName: z.string(),
  lastName: z.string(),
  gender: z.nativeEnum(Gender),
  birthDate: z.date(),
  addressLine1: z.string(),
  addressCity: z.string(),
  addressPostCode: z.string(),
  addressCountry: z.string(),
})

export const FamilyHistory = z.object({
  ...common,
  cancer: z.nativeEnum(YesNoUnknown),
  miscarriage: z.nativeEnum(YesNoUnknown),
  unexplainedDeath: z.nativeEnum(YesNoUnknown),
  longTermTreatment: z.nativeEnum(YesNoUnknown),
  mentalHealthIssues: z.nativeEnum(YesNoUnknown),
  heartProblems: z.nativeEnum(YesNoUnknown),
  organTransplantation: z.nativeEnum(YesNoUnknown),
  visionLoss: z.nativeEnum(YesNoUnknown),
  hearingLoss: z.nativeEnum(YesNoUnknown),
  stroke: z.nativeEnum(YesNoUnknown),
})

const bodyMeasurement = (maxValue: number) =>
  z.any().refine((val) => {
    const schema = z.number().int().positive().max(maxValue)

    try {
      schema.parse(val)
      return true
    } catch {
      return false
    }
  }, "Please insert a whole number between 1 and " + maxValue)
export const BodyMeasurements = z.object({
  ...common,
  height: bodyMeasurement(250),
  weight: bodyMeasurement(400),
})

export const ZSubjectSymptom = z.object({
  createdAt: z.date().optional(),
  updatedAt: z.date().optional(),
  subjectId: z.string().optional(),
  id: z.string().optional(),
  symptomKey: z.string(),
  beginYear: z.number().int().min(1950).max(new Date().getFullYear()),
  ongoing: z.boolean(),
})

export const ClinicalInfo = z.object({
  ...common,
  symptoms: ZSubjectSymptom.array(),
  hasSymptoms: z.boolean(),
})

export const Consents = z.object({
  ...common,
  formConsent: z.boolean(),
  researchConsent: booleanString,
  incidentalFindingsConsent: booleanString,
})

export const OnSubmit = z.object({ onSubmit: z.function().optional() })
