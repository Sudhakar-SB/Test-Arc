import { PatientRegistrationResponse } from "../../../lims/live-health/registerPatient"
import { SubjectSymptom } from "../../../../db"
import { AuthenticatedMiddlewareCtx } from "blitz"
import addAdditionalPatientInfoLIMS from "../../../lims/live-health/addAdditionalPatientInfo"
import { AuthorizedSubject } from "../../../security/authorization/authorizeSubjectAccess"

function bool2String(b: boolean | null | undefined) {
  return b ? "Yes" : "No"
}

function symptom2HTML(symptom: SubjectSymptom) {
  return `<tr><td>${symptom.symptomKey}</td><td>${symptom.beginYear}</td><td>${
    symptom.ongoing ? "ONGOING" : ""
  }</td></tr>`
}

export async function addAdditionalPatientInfo(
  registrationResponse: PatientRegistrationResponse,
  existingSubject: AuthorizedSubject,
  ctx: AuthenticatedMiddlewareCtx
) {
  await addAdditionalPatientInfoLIMS({
    sampleId: registrationResponse.reportDetails[0].sampleId,
    data: {
      values: [
        {
          testName: "CANCER",
          value: existingSubject.cancer!,
        },
        {
          testName: "DEATH",
          value: existingSubject.unexplainedDeath!,
        },
        {
          testName: "TREATMENT",
          value: existingSubject.longTermTreatment!,
        },
        {
          testName: "MENTAL",
          value: existingSubject.mentalHealthIssues!,
        },
        {
          testName: "HEART",
          value: existingSubject.heartProblems!,
        },
        {
          testName: "ORGAN",
          value: existingSubject.organTransplantation!,
        },
        {
          testName: "BLINDNESS",
          value: existingSubject.visionLoss!,
        },
        {
          testName: "DEAFNESS",
          value: existingSubject.hearingLoss!,
        },
        {
          testName: "STROKE",
          value: existingSubject.stroke!,
        },
        {
          testName: "MISCARRIAGE",
          value: existingSubject.miscarriage!,
        },
        {
          testName: "CONSENT",
          value: bool2String(existingSubject.formConsent),
        },
        {
          testName: "RESEARCH",
          value: bool2String(existingSubject.researchConsent),
        },
        {
          testName: "FINDINGS",
          value: bool2String(existingSubject.incidentalFindingsConsent),
        },
        {
          testName: "HISTORY",
          value: `<table border="0" class="cke_show_border" cellspacing="0" cellpadding="5" style="width: 500px;">
                        ${existingSubject.symptoms.map(symptom2HTML).join("\n")}
                    </table>`,
        },
        {
          testName: "YEAR",
          value: "",
        },
        {
          testName: "ONGOING",
          value: "",
        },
        {
          testName: "SYMPTOM",
          value: "",
        },
      ],
    },
  })
}
