import db, { Subject } from "../../../../db"
import { AuthenticatedMiddlewareCtx } from "blitz"
import moment from "moment"
import registerPatientLIMS from "../../../lims/live-health/registerPatient"
import { getLIMSAccountId, getLIMSFamilyId, getLIMSSubjectId } from "../../../lims/utils"

export async function registerPatient(existingSubject: Subject, ctx: AuthenticatedMiddlewareCtx) {
  const user = await db.user.findFirst({
    where: { id: ctx.session.userId },
  })
  const age = moment(new Date()).diff(existingSubject.birthDate, "y")

  if (!user) {
    throw new Error("User does not exist")
  }

  const response = await registerPatientLIMS({
    fullName: `${existingSubject.firstName} ${existingSubject.lastName}`,
    age,
    gender: existingSubject.gender!,
    dob: moment(existingSubject.birthDate!).format("YYYY-MM-DD"),
    area: existingSubject.addressLine1!,
    city: `${existingSubject.addressCity}, ${existingSubject.addressCountry}`,
    pincode: existingSubject.addressPostCode!,
    labPatientId: getLIMSSubjectId(existingSubject.internalId),
    insuranceNo: getLIMSAccountId(user.internalId),
    nationalIdentityNumber: getLIMSFamilyId(user.internalId, existingSubject.familyMember!),
    height: existingSubject.height!.toString(),
    weight: existingSubject.weight!.toString(),
    billDetails: {
      comments: existingSubject.paymentId,
      orderNumber: existingSubject.boxId!,
      billDate: moment(existingSubject.sampleCollectionDate!).toISOString(),
    },
  })

  return response
}
