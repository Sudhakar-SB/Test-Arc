import authorizeSubjectMutation from "app/security/authorization/authorizeSubjectMutation"
import aws from "aws-sdk"
import { NotFoundError, resolver } from "blitz"
import db from "db"
import * as z from "zod"
import { buildS3Key } from "../utils/subjectFileUtils"

const DeleteSubjectFile = z.object({
  fileId: z.string(),
  subjectId: z.string(),
})

export default resolver.pipe(
  resolver.zod(DeleteSubjectFile),
  resolver.authorize(),
  async function deleteSubjectFile({ fileId, subjectId }, ctx) {
    await authorizeSubjectMutation(subjectId, ctx)

    const file = await db.subjectFile.findFirst({
      where: {
        id: fileId,
        subjectId,
      },
    })

    if (!file) {
      throw new NotFoundError(`No file by this id found`)
    }

    aws.config.update({
      accessKeyId: process.env.AWS_S3_ACCESS_KEY,
      secretAccessKey: process.env.AWS_S3_SECRET_KEY,
      region: process.env.AWS_S3_REGION,
      signatureVersion: "v4",
    })

    const s3 = new aws.S3()

    const key = buildS3Key(subjectId, file.id, file.name)

    await s3
      .deleteObject({
        Bucket: process.env.NEXT_PUBLIC_BUCKET_NAME!,
        Key: key,
      })
      .promise()

    // Only delete db record once we know the s3 file was successfully removed
    await db.subjectFile.delete({ where: { id: fileId } })
  }
)
