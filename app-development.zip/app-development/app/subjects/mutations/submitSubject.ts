import authorizeSubjectMutation from "app/security/authorization/authorizeSubjectMutation"
import { AuthenticatedMiddlewareCtx, resolver } from "blitz"
import db, { Subject, SubjectStatus } from "db"
import _ from "lodash"
import authorizeUserSession from "../../security/authorization/authorizeUserSession"
import { getInitialValues as getMeasurementValues } from "../components/BodyMeasurementsForm"
import validateSubject from "../utils/validateSubject"
import {
  BodyMeasurements,
  ClinicalInfo,
  Consents,
  FamilyHistory,
  PersonalInfo,
} from "../validations"
import * as z from "zod"
import { registerPatient } from "../logic/submitSubject/registerPatient"
import { addAdditionalPatientInfo } from "../logic/submitSubject/addAdditionalPatientInfo"
import { AuthorizedSubject } from "../../security/authorization/authorizeSubjectAccess"

async function authorize(input: z.infer<typeof Consents>, ctx: AuthenticatedMiddlewareCtx) {
  authorizeUserSession(input.userId, ctx)
  const existingSubject = await authorizeSubjectMutation(input.id, ctx)

  const isSubjectValid =
    validateSubject(existingSubject, PersonalInfo) &&
    validateSubject(existingSubject, FamilyHistory) &&
    validateSubject(getMeasurementValues(existingSubject), BodyMeasurements) &&
    validateSubject(existingSubject, ClinicalInfo) &&
    validateSubject(input, Consents)

  if (!isSubjectValid) {
    throw new Error("Some of the previous steps have not been completed properly")
  }

  return existingSubject
}

async function callLIMS(existingSubject: AuthorizedSubject, ctx: AuthenticatedMiddlewareCtx) {
  const registrationResponse = await registerPatient(existingSubject, ctx)
  await addAdditionalPatientInfo(registrationResponse, existingSubject, ctx)
}

async function updateDB(input: z.infer<typeof Consents>) {
  const { id, userId, formConsent, ...yesNoValues } = input
  const data = _.mapValues(yesNoValues, (val) => val === "true")

  const subject = await db.subject.update({
    where: { id },
    data: { ...data, formConsent, status: SubjectStatus.Submitted },
    include: { symptoms: true, files: true },
  })

  return subject
}

export default resolver.pipe(resolver.zod(Consents), resolver.authorize(), async (input, ctx) => {
  const existingSubject = await authorize(input, ctx)
  await callLIMS(existingSubject, ctx)

  return await updateDB(input)
})
