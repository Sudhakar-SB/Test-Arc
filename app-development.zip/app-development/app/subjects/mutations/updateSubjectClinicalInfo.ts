import authorizeSubjectMutation from "app/security/authorization/authorizeSubjectMutation"
import authorizeUserSession from "app/security/authorization/authorizeUserSession"
import { resolver } from "blitz"
import db from "db"
import _ from "lodash"
import { ClinicalInfo } from "../validations"

export default resolver.pipe(
  resolver.zod(ClinicalInfo),
  resolver.authorize(),
  async (input, ctx) => {
    authorizeUserSession(input.userId, ctx)
    const { id, userId, symptoms, ...data } = input

    const existingSubject = await authorizeSubjectMutation(id, ctx)

    const { symptoms: existingSymptoms } = existingSubject

    const deletedSymptoms = _.differenceWith(existingSymptoms, symptoms, (a, b) => a.id === b.id)

    if (deletedSymptoms.length > 0) {
      await Promise.all(
        deletedSymptoms.map(async ({ id }) => await db.subjectSymptom.delete({ where: { id } }))
      )
    }

    const updatedSymptoms = _.intersectionWith(symptoms, existingSymptoms, (a, b) => a.id === b.id)
    if (updatedSymptoms.length > 0) {
      await Promise.all(
        updatedSymptoms.map(
          async ({ id, ...data }) => await db.subjectSymptom.update({ where: { id }, data })
        )
      )
    }

    const newSymptoms = _.differenceWith(symptoms, existingSymptoms, (a, b) => a.id === b.id)

    const updatedSubject = await db.subject.update({
      where: { id },
      include: { symptoms: true, files: true },
      data: { ...data, symptoms: { createMany: { data: newSymptoms } } },
    })

    return updatedSubject
  }
)
