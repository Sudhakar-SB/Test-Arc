import authorizeSubjectMutation from "app/security/authorization/authorizeSubjectMutation"
import { resolver } from "blitz"
import db from "db"
import * as z from "zod"

const DeleteSubject = z
  .object({
    id: z.string(),
  })
  .nonstrict()

export default resolver.pipe(
  resolver.zod(DeleteSubject),
  resolver.authorize(),
  async ({ id }, ctx) => {
    await authorizeSubjectMutation(id, ctx)

    const subject = await db.subject.deleteMany({ where: { id } })

    return subject
  }
)
