import authorizeSubjectMutation from "app/security/authorization/authorizeSubjectMutation"
import { resolver } from "blitz"
import db from "db"
import authorizeUserSession from "../../security/authorization/authorizeUserSession"
import { PersonalInfo } from "../validations"
import authorizeBoxId from "../../security/authorization/authorizeBoxId"

export default resolver.pipe(
  resolver.zod(PersonalInfo),
  resolver.authorize(),
  async (input, ctx) => {
    authorizeUserSession(input.userId, ctx)
    await authorizeSubjectMutation(input.id, ctx)
    await authorizeBoxId(input.boxId, input.id)

    const { id, userId, ...data } = input
    const subject = await db.subject.update({
      where: { id },
      data: { ...data, familyMember: data.familyMember === "true" },
      include: { symptoms: true, files: true },
    })

    return subject
  }
)
