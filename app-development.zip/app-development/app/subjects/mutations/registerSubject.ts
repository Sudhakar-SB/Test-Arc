import { resolver } from "blitz"
import db from "db"
import { RegisterSubject } from "../validations"
import authorizePaymentId from "../../security/authorization/authorizePaymentId"

export default resolver.pipe(
  resolver.zod(RegisterSubject),
  resolver.authorize(),
  async ({ paymentId }, ctx) => {
    await authorizePaymentId(paymentId)
    const subject = await db.subject.create({ data: { paymentId, userId: ctx.session.userId } })

    return subject
  }
)
