import authorizeSubjectMutation from "app/security/authorization/authorizeSubjectMutation"
import aws from "aws-sdk"
import { resolver } from "blitz"
import db from "db"
import * as z from "zod"
import { ALLOWED_FILE_TYPES } from "../constants"
import { buildS3Key } from "../utils/subjectFileUtils"

const ONE_MB = 1048576
const MAX_FILE_SIZE = 20 * ONE_MB // up to 20 MB

const CreateSubjectFile = z.object({
  name: z.string(),
  size: z.number().min(1).max(MAX_FILE_SIZE, "File size should be less than or equal to 20 MB"),
  type: z
    .string()
    .refine(
      (type) => ALLOWED_FILE_TYPES.indexOf(type) > -1,
      `File extension should be one of ${ALLOWED_FILE_TYPES.map(
        (type) => `.${type.split("/")[1].toLowerCase()}`
      ).join(", ")}`
    ),
  subjectId: z.string(),
})

export default resolver.pipe(
  resolver.zod(CreateSubjectFile),
  resolver.authorize(),
  async function createSubjectFileAndUploadUrl({ name, size, subjectId }, ctx) {
    await authorizeSubjectMutation(subjectId, ctx)

    const file = await db.subjectFile.create({
      data: { name, size, subjectId },
    })

    const awsConfig = {
      accessKeyId: process.env.AWS_ACCESS_KEY,
      secretAccessKey: process.env.AWS_SECRET_KEY,
      region: process.env.AWS_REGION,
      signatureVersion: "v4",
    }

    aws.config.update(awsConfig)

    const s3 = new aws.S3()

    const key = buildS3Key(subjectId, file.id, name)

    /**
     * This uses createPresignedPost instead of getSignedUrlPromise
     * to allow setting max/min file sizes with content-length-range.
     */
    const presignedPost = await s3.createPresignedPost({
      Bucket: process.env.NEXT_PUBLIC_BUCKET_NAME,
      Fields: {
        key,
      },
      Expires: 60, // seconds
      Conditions: [["content-length-range", 0, MAX_FILE_SIZE]],
    })

    return {
      attachment: file,
      presignedPost,
    }
  }
)
