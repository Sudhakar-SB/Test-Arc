import { ArrowBackIcon } from "@chakra-ui/icons"
import { Box, Link, Text, VStack } from "@chakra-ui/layout"
import { Skeleton } from "@chakra-ui/react"
import Sidebar from "app/core/components/Sidebar"
import { Link as BlitzLink, Routes, useRouter } from "blitz"
import React, { FC } from "react"
import { SidebarProps } from "../../core/components/Sidebar"
import { getInitialValues as getMeasurementValues } from "../components/BodyMeasurementsForm"
import { useSubjectContext } from "../utils/SubjectContext"
import validateSubject from "../utils/validateSubject"
import { BodyMeasurements, ClinicalInfo, FamilyHistory, PersonalInfo } from "../validations"

export const SubjectWizardSidebarLoader = () => {
  return (
    <Sidebar
      topComponent={
        <VStack align="start" spacing={10} mt={10}>
          {new Array([80, 130, 140, 70, 90]).map((width) => (
            <Box p={4} key={width.toString()}>
              <Skeleton height="24px" width={`${width}px`} />
            </Box>
          ))}
        </VStack>
      }
      bottomComponent={
        <Box my={4}>
          <Skeleton height="16px" width="80px" />
        </Box>
      }
    />
  )
}

const SubjectWizardSidebar: FC<SidebarProps> = ({ ...restProps }) => {
  const router = useRouter()
  const { subject } = useSubjectContext()

  if (!subject) {
    return <SubjectWizardSidebarLoader />
  }

  const { id: subjectId } = subject

  const routes = [
    {
      key: "personal-info",
      href: Routes.SubjectPersonalInfo({ subjectId }),
      label: "Personal",
    },
    {
      key: "family-history",
      href: Routes.SubjectFamilyHistory({ subjectId }),
      label: "Family History",
      isDisabled: !validateSubject(subject, PersonalInfo),
    },
    {
      key: "measurements",
      href: Routes.SubjectBodyMeasurements({ subjectId }),
      label: "Physical Information",
      isDisabled: !validateSubject(subject, FamilyHistory),
    },
    {
      key: "clinical",
      href: Routes.SubjectClinicalInfo({ subjectId }),
      label: "Clinical",
      isDisabled: !validateSubject(getMeasurementValues(subject), BodyMeasurements),
    },
    {
      key: "summary",
      href: Routes.SubjectSummary({ subjectId }),
      label: "Summary",
      isDisabled: !validateSubject(subject, ClinicalInfo),
    },
  ]

  return (
    <Sidebar
      topComponent={
        <VStack align="start" spacing={6} mt={10}>
          {routes.map(({ key, href, label, isDisabled }, index) => {
            const isActive = router.pathname === href.pathname

            if (isDisabled) {
              return (
                <Text fontSize="md" fontWeight="bold" color="gray.400" key={key} p={4}>
                  {index + 1}. {label}
                </Text>
              )
            }

            return (
              <BlitzLink key={key} passHref href={href}>
                <Link
                  display="flex"
                  w="full"
                  alignItems="center"
                  color="brand.yellowMarker"
                  background={isActive ? "white" : undefined}
                  p={4}
                  _hover={{ color: "yellow.200", background: isActive ? "white" : "gray.50" }}
                  _focus={{ boxShadow: "none" }}
                >
                  <Text fontSize="md" fontWeight="bold" color={"brand.expertBlue"}>
                    {index + 1}. {label}
                  </Text>
                </Link>
              </BlitzLink>
            )
          })}
        </VStack>
      }
      bottomComponent={
        <Box my={4}>
          <BlitzLink href={Routes.SubjectsPage()} passHref>
            <Link display="inline-flex" alignItems="center" _hover={{ textDecoration: "none" }}>
              <ArrowBackIcon mr={2} />
              <Text>Exit</Text>
            </Link>
          </BlitzLink>
        </Box>
      }
      {...restProps}
    />
  )
}

export default SubjectWizardSidebar
