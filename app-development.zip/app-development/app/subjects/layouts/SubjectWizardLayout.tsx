import { Center } from "@chakra-ui/layout"
import { Spinner } from "@chakra-ui/spinner"
import { CONTENT_HEIGHT } from "app/core/constants"
import Layout, { LayoutProps } from "app/core/layouts/Layout"
import getSubject from "app/subjects/queries/getSubject"
import { useParam, useQuery } from "blitz"
import React, { FC } from "react"
import { SubjectContext } from "../utils/SubjectContext"
import SubjectWizardSidebar, { SubjectWizardSidebarLoader } from "./SubjectWizardSidebar"

const SubjectWizardLayoutLoader = () => {
  return (
    <Layout hasSidebar sidebarComponent={SubjectWizardSidebarLoader}>
      <Center minH={CONTENT_HEIGHT}>
        <Spinner />
      </Center>
    </Layout>
  )
}

const SubjectWizardLayout: FC<LayoutProps> = ({ children, ...props }) => {
  const subjectId = useParam("subjectId", "string")

  const [subject, { setQueryData, refetch, isLoading }] = useQuery(
    getSubject,
    { id: subjectId! },
    { suspense: false }
  )

  if (isLoading) {
    return <SubjectWizardLayoutLoader />
  }

  return (
    <SubjectContext.Provider value={{ subject, setSubject: setQueryData, refetchSubject: refetch }}>
      <Layout hasSidebar sidebarComponent={SubjectWizardSidebar} {...props}>
        {children}
      </Layout>
    </SubjectContext.Provider>
  )
}

export default SubjectWizardLayout
