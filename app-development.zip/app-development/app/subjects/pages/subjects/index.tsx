import { Heading } from "@chakra-ui/layout"
import Layout from "app/core/layouts/Layout"
import { BlitzPage } from "blitz"
import { Suspense } from "react"
import RegisterSubjectForm from "../../components/RegisterSubjectForm"
import SubjectsList, { SubjectsListLoader } from "../../components/SubjectsList"

export const SubjectsPage: BlitzPage = () => {
  return (
    <>
      <Heading size="lg">Register New Subject</Heading>
      <RegisterSubjectForm />

      <Heading size="lg" mt={10} mb={4}>
        My Subjects
      </Heading>

      <Suspense fallback={<SubjectsListLoader />}>
        <SubjectsList />
      </Suspense>
    </>
  )
}

SubjectsPage.authenticate = true
SubjectsPage.getLayout = (page) => (
  <Layout hasSidebar title="My Subjects" px={12} py={10}>
    {page}
  </Layout>
)

export default SubjectsPage
