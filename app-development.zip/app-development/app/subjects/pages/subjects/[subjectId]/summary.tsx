import { Heading } from "@chakra-ui/layout"
import { Center, Spinner } from "@chakra-ui/react"
import SubjectWizardLayout from "app/subjects/layouts/SubjectWizardLayout"
import { BlitzPage } from "blitz"
import { Suspense } from "react"
import ConsentForm from "../../../components/ConsentForm"
import SummaryBox from "../../../components/SummaryBox"

export const SubjectSummary: BlitzPage = () => {
  return (
    <>
      <Heading size="lg">Summary</Heading>
      <Suspense
        fallback={
          <Center height="200px">
            <Spinner />
          </Center>
        }
      >
        <SummaryBox />
        <ConsentForm />
      </Suspense>
    </>
  )
}

SubjectSummary.authenticate = true
SubjectSummary.getLayout = (page) => (
  <SubjectWizardLayout title="Summary" px={12} py={10}>
    {page}
  </SubjectWizardLayout>
)

export default SubjectSummary
