import { Center, Heading, Spinner } from "@chakra-ui/react"
import SubjectWizardLayout from "app/subjects/layouts/SubjectWizardLayout"
import { BlitzPage } from "blitz"
import { Suspense } from "react"
import PersonalInfoForm from "../../../components/PersonalInfoForm"

export const SubjectPersonalInfo: BlitzPage = () => {
  return (
    <>
      <Heading size="lg">Personal Information</Heading>
      <Suspense
        fallback={
          <Center height="200px">
            <Spinner />
          </Center>
        }
      >
        <PersonalInfoForm />
      </Suspense>
    </>
  )
}

SubjectPersonalInfo.authenticate = true
SubjectPersonalInfo.getLayout = (page) => (
  <SubjectWizardLayout title="Personal Information" px={12} py={10}>
    {page}
  </SubjectWizardLayout>
)

export default SubjectPersonalInfo
