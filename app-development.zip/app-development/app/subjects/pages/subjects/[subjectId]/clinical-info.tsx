import { Box, Center, Flex, Heading, Spinner } from "@chakra-ui/react"
import { CONTAINER_MAX_WIDTH, CONTENT_WIDTH, SIDEBAR_WIDTH } from "app/core/constants"
import BodyDiagram from "app/subjects/components/BodyDiagram"
import ClinicalInfoForm from "app/subjects/components/ClinicalInfoForm"
import SubjectWizardLayout from "app/subjects/layouts/SubjectWizardLayout"
import { BlitzPage } from "blitz"
import { Suspense } from "react"

export const SubjectClinicalInfo: BlitzPage = () => {
  return (
    <>
      <Heading size="lg" mb={8}>
        Clinical Information
      </Heading>
      <Flex flexDirection={["column-reverse", null, null, null, "row"]}>
        <Box flex={`0 0 ${CONTENT_WIDTH - 100}px`} mr={[0, null, null, null, 6]}>
          <Suspense
            fallback={
              <Center height="200px">
                <Spinner />
              </Center>
            }
          >
            <ClinicalInfoForm />
          </Suspense>
        </Box>
        <BodyDiagram />
      </Flex>
    </>
  )
}

SubjectClinicalInfo.authenticate = true
SubjectClinicalInfo.getLayout = (page) => (
  <SubjectWizardLayout
    title="Clinical Information"
    w={`${CONTAINER_MAX_WIDTH - SIDEBAR_WIDTH}px`}
    py={10}
    pl={10}
    pr={[6, null, null, null, 0]}
  >
    {page}
  </SubjectWizardLayout>
)

export default SubjectClinicalInfo
