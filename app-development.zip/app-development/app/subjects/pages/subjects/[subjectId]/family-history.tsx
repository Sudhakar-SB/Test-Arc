import { Heading } from "@chakra-ui/layout"
import { Center, Spinner } from "@chakra-ui/react"
import FamilyHistoryForm from "app/subjects/components/FamilyHistoryForm"
import SubjectWizardLayout from "app/subjects/layouts/SubjectWizardLayout"
import { BlitzPage } from "blitz"
import { Suspense } from "react"

export const SubjectFamilyHistory: BlitzPage = () => {
  return (
    <>
      <Heading size="lg">Family History</Heading>
      <Suspense
        fallback={
          <Center height="200px">
            <Spinner />
          </Center>
        }
      >
        <FamilyHistoryForm />
      </Suspense>
    </>
  )
}

SubjectFamilyHistory.authenticate = true
SubjectFamilyHistory.getLayout = (page) => (
  <SubjectWizardLayout title="Family History" px={12} py={10}>
    {page}
  </SubjectWizardLayout>
)

export default SubjectFamilyHistory
