import { Subject, User } from "db"

export const getLIMSSubjectId = (internalSubjectId: Subject["internalId"]): string => {
  return `4${internalSubjectId.toString().padStart(8, "0")}`
}

export const getLIMSAccountId = (internalAccountId: User["internalId"]): string => {
  return `8${internalAccountId.toString().padStart(8, "0")}`
}

export const getLIMSFamilyId = (
  internalUserId: User["internalId"],
  isInsideFamily: boolean
): string => {
  return `9${internalUserId.toString().padStart(8, "0")}${isInsideFamily ? 1 : 2}`
}
