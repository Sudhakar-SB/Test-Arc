import { BadGatewayError } from "app/core/utils/errors"
import { DEVICE_AUTH, LAB_ID } from "./constants"

export interface AdditionalPatientInfo {
  sampleId: string
  data: {
    values: [
      {
        testName: "CANCER"
        value: string
      },
      {
        testName: "DEATH"
        value: string
      },
      {
        testName: "TREATMENT"
        value: string
      },
      {
        testName: "MENTAL"
        value: string
      },
      {
        testName: "HEART"
        value: string
      },
      {
        testName: "ORGAN"
        value: string
      },
      {
        testName: "BLINDNESS"
        value: string
      },
      {
        testName: "DEAFNESS"
        value: string
      },
      {
        testName: "STROKE"
        value: string
      },
      {
        testName: "MISCARRIAGE"
        value: string
      },
      {
        testName: "CONSENT"
        value: string
      },
      {
        testName: "RESEARCH"
        value: string
      },
      {
        testName: "FINDINGS"
        value: string
      },
      {
        testName: "HISTORY"
        value: string
      },
      {
        testName: "YEAR"
        value: string
      },
      {
        testName: "ONGOING"
        value: string
      },
      {
        testName: "SYMPTOM"
        value: string
      }
    ]
  }
}

interface Payload extends AdditionalPatientInfo {
  deviceAuth: string
  labId: string
}

const headers = new Headers()
headers.append("Content-Type", "application/json")

const addAdditionalPatientInfo = async (params: AdditionalPatientInfo) => {
  const payload: Payload = {
    deviceAuth: DEVICE_AUTH,
    labId: LAB_ID,
    ...params,
  }

  const requestOptions: RequestInit = {
    method: "POST",
    headers,
    body: JSON.stringify(payload),
    redirect: "follow",
  }

  return await fetch(`${process.env.LIVE_HEALTH_HOST}/dataPartialFromDevice/`, requestOptions).then(
    async (response) => {
      if (!response.ok) {
        throw new BadGatewayError(await response.text())
      }
      return response.json()
    }
  )
}

export default addAdditionalPatientInfo
