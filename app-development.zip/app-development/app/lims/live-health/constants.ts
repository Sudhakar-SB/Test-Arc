export const TEST_ID = 4689816
export const DEVICE_AUTH = "1ca86864-c750-11eb-aab2-0a5161578922"
export const LAB_ID = "1336"
