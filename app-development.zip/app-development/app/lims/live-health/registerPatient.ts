// https://api.livehealth.in/#a4bf4d5a-11a5-4a5c-a955-9c88510760bb

import { BadGatewayError } from "app/core/utils/errors"
import { TEST_ID } from "./constants"

export interface PatientRegistrationData {
  fullName: string
  age: number
  gender: "Male" | "Female" | "Other" | "M" | "F" | "O"
  dob: string
  city: string
  pincode: string
  labPatientId: string
  insuranceNo: string
  nationalIdentityNumber: string
  billDetails: BillDetails
  area: string
  height: string
  weight: string
}

interface Payload extends PatientRegistrationData {
  // the following params are marked as optional in docs,
  // but seem to be required, accepting empty string values
  mobile: string // Numeric value, without country code	(eg: 94****)
  email: string // Patient email Address (eg: jane.doe@livehealth.in)
  designation: "Miss" | "Mr." | "Mrs." | "Dr" | "" // Patient Designation (eg: Miss/Mr./Mrs./Dr)
  patientType: "OP" | "IP" | ""
  billDetails: BillDetailsPayload

  // truly optional params
  patientId?: string
  passportNo?: string
  panNumber?: string
  aadharNumber?: string
  nationality?: string
  ethnicity?: string
  workerCode?: string
  doctorCode?: string
}

interface BillDetails {
  comments: string
  orderNumber: string
  billDate: string
}

interface BillDetailsPayload extends BillDetails {
  // the following params are marked as optional in docs,
  // but seem to be required, accepting empty string values
  advance: number
  paymentType: string
  testList: [Test, ...Test[]]
  paymentList: Payment[]

  // truly optional params
  emergencyFlag?: string
  totalAmount?: string
  otherReferral?: string
  sampleId?: string
  organisationName?: string
  additionalAmount?: number
  organizationIdLH?: number
}

interface Payment {
  paymentType?: string //	Payment Type (eg: Cash)
  paymentAmount?: number //	Amount Paid (eg: 100)
  issueBank?: string
}

interface Test {
  testID: number //Test ID (eg: 220119)
  testCode?: string //	Test code
  integrationCode?: string //	Integration Code
  dictionaryId?: number // Dictionary ID
}

interface ReportDetail {
  testAmount: string
  testCode: string
  testCategory: string
  departmentName: string
  sampleId: string
  dictionaryId: string
  testID: number
  CentreReportId: number
  integrationCode: string
  testName: string
}

export interface PatientRegistrationResponse {
  age: string
  code: number
  reportDetails: [ReportDetail, ...ReportDetail[]]
  gender: string
  Message: string
  unMappedTestsUnderProfile: any[]
  moreThanOneDictMappedTests: any[]
  patientId: number
  billId: number
}

const headers = new Headers()
headers.append("Content-Type", "application/json")

const registerPatient = async (params: PatientRegistrationData) => {
  const payload: Payload = {
    ...params,
    mobile: "",
    email: "",
    designation: "",
    patientType: "",
    billDetails: {
      ...params.billDetails,
      advance: 0,
      paymentType: "",
      organizationIdLH: Number(process.env.LIVE_HEALTH_ORG_ID),
      testList: [
        {
          testID: TEST_ID,
        },
      ],
      paymentList: [],
    },
  }

  const requestOptions: RequestInit = {
    method: "POST",
    headers,
    body: JSON.stringify(payload),
    redirect: "follow",
  }

  return await fetch(
    `${process.env.LIVE_HEALTH_HOST}/LHRegisterBillAPI/${process.env.LIVE_HEALTH_LAB_TOKEN}/`,
    requestOptions
  ).then(async (response: Response) => {
    if (!response.ok) {
      throw new BadGatewayError(await response.text())
    }
    return (await response.json()) as PatientRegistrationResponse
  })
}

export default registerPatient
