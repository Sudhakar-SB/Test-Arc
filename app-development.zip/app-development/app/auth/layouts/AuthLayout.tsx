import { Box, Center, Container, Heading } from "@chakra-ui/react"
import { EmblemGraphic } from "app/theme/graphics"
import { Head } from "blitz"
import { ReactNode } from "react"

type LayoutProps = {
  title?: string
  children: ReactNode
}

const AuthLayout = ({ title, children }: LayoutProps) => {
  return (
    <Center
      minHeight="100vh"
      background="expertBlue.700"
      color="white"
      position="relative"
      overflow="auto"
    >
      <Head>
        <title>{title ? `${title} - Arcensus` : "Arcensus"}</title>
        <link rel="icon" href="/favicon.png" />
      </Head>

      <Box
        position="absolute"
        top="0"
        left="0"
        width="100%"
        height="100%"
        overflow="hidden"
        pointerEvents="none"
      >
        <EmblemGraphic
          position="absolute"
          top="0"
          left="0"
          width="60vw"
          height="auto"
          transform="translate(-25%, -25%)"
          zIndex="0"
          opacity="0.1"
        />
      </Box>

      <Container maxW="380px" py={6}>
        <Center>
          <Heading as="h1" fontSize="5xl">
            arcensus
          </Heading>
        </Center>
        {children}
      </Container>
    </Center>
  )
}

export default AuthLayout
