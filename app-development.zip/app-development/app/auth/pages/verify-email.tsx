import {
  Alert,
  AlertDescription,
  AlertIcon,
  AlertTitle,
  Flex,
  Heading,
  Link,
  Spinner,
  Text,
} from "@chakra-ui/react"
import AuthLayout from "app/auth/layouts/AuthLayout"
import { BlitzPage, Link as BlitzLink, Routes, useMutation, useRouterQuery } from "blitz"
import { useEffect } from "react"
import verifyEmail from "../mutations/verifyEmail"

const VerifyEmailPage: BlitzPage = () => {
  const { token } = useRouterQuery()
  const [verifyEmailMutation, { isSuccess, isError, isLoading, error }] = useMutation(verifyEmail)

  useEffect(() => {
    if (!isSuccess && !isError) {
      verifyEmailMutation({ token: token as string })
    }
  }, [isSuccess, isError, token, verifyEmailMutation])

  return (
    <>
      <Heading size="sm" textAlign="center" mt={4}>
        Verify your email
      </Heading>

      {isLoading && (
        <Flex flexDirection="column" alignItems="center" mt={8}>
          <Spinner />
          <Text mt={4}>Verifying...</Text>
        </Flex>
      )}

      {isError && (
        <Alert
          status="error"
          flexDirection="column"
          alignItems="center"
          justifyContent="center"
          textAlign="center"
          variant="solid"
          my={8}
        >
          <AlertIcon boxSize="40px" mr={0} mb={4} />
          <AlertTitle>Error!</AlertTitle>
          <AlertDescription>
            {(error as Error)?.message}
            <br />
            Go to{" "}
            <BlitzLink href={Routes.ResendVerificationPage()} passHref>
              <Link>email verification page</Link>
            </BlitzLink>
          </AlertDescription>
        </Alert>
      )}

      {isSuccess && (
        <Alert
          status="success"
          flexDirection="column"
          alignItems="center"
          justifyContent="center"
          textAlign="center"
          variant="solid"
          my={8}
        >
          <AlertIcon boxSize="40px" mr={0} mb={4} />
          <AlertTitle>Email verified successfully</AlertTitle>
          <AlertDescription>
            Go to{" "}
            <BlitzLink href={Routes.LoginPage()} passHref>
              <Link>Login Page</Link>
            </BlitzLink>
          </AlertDescription>
        </Alert>
      )}
    </>
  )
}

VerifyEmailPage.redirectAuthenticatedTo = "/"
VerifyEmailPage.getLayout = (page) => <AuthLayout title="Verify Email">{page}</AuthLayout>

export default VerifyEmailPage
