import { Alert, AlertDescription, AlertIcon, AlertTitle } from "@chakra-ui/alert"
import { Center, Heading, Link } from "@chakra-ui/layout"
import AuthLayout from "app/auth/layouts/AuthLayout"
import forgotPassword from "app/auth/mutations/forgotPassword"
import { ForgotPassword } from "app/auth/validations"
import { Form, FORM_ERROR } from "app/core/components/Form"
import TextField from "app/core/components/TextField"
import { BlitzPage, Link as BlitzLink, Routes, useMutation } from "blitz"

const ForgotPasswordPage: BlitzPage = () => {
  const [forgotPasswordMutation, { isSuccess }] = useMutation(forgotPassword)

  return (
    <>
      <Heading size="sm" textAlign="center" mt={4}>
        Forgot your password?
      </Heading>

      {isSuccess ? (
        <Alert
          status="success"
          flexDirection="column"
          alignItems="center"
          justifyContent="center"
          textAlign="center"
          variant="solid"
          my={8}
        >
          <AlertIcon boxSize="40px" mr={0} mb={4} />
          <AlertTitle>Request Submitted</AlertTitle>
          <AlertDescription>
            If your email is in our system, you will receive instructions to reset your password
            shortly.
          </AlertDescription>
        </Alert>
      ) : (
        <Form
          submitText="Send Reset Password Instructions"
          schema={ForgotPassword}
          initialValues={{ email: "" }}
          onSubmit={async (values) => {
            try {
              await forgotPasswordMutation(values)
            } catch (error) {
              return {
                [FORM_ERROR]: "Sorry, we had an unexpected error. Please try again.",
              }
            }
          }}
          buttonProps={{
            colorScheme: "lightBlue",
            color: "brand.expertBlue",
          }}
        >
          <TextField name="email" label="Email" placeholder="Email" variant="filled" />
        </Form>
      )}
      <Center mt={4}>
        <BlitzLink href={Routes.LoginPage()} passHref>
          <Link>Login</Link>
        </BlitzLink>
      </Center>
    </>
  )
}

ForgotPasswordPage.redirectAuthenticatedTo = "/"
ForgotPasswordPage.getLayout = (page) => (
  <AuthLayout title="Forgot Your Password?">{page}</AuthLayout>
)

export default ForgotPasswordPage
