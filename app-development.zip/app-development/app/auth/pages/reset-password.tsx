import { Alert, AlertDescription, AlertIcon, AlertTitle } from "@chakra-ui/alert"
import { Center, Heading, Link } from "@chakra-ui/layout"
import AuthLayout from "app/auth/layouts/AuthLayout"
import resetPassword from "app/auth/mutations/resetPassword"
import { ResetPasswordWithoutToken } from "app/auth/validations"
import { Form, FORM_ERROR } from "app/core/components/Form"
import PasswordField from "app/core/components/PasswordField"
import { BlitzPage, Link as BlitzLink, Routes, useMutation, useRouterQuery } from "blitz"

const ResetPasswordPage: BlitzPage = () => {
  const query = useRouterQuery()
  const [resetPasswordMutation, { isSuccess }] = useMutation(resetPassword)

  return (
    <>
      <Heading size="sm" textAlign="center" mt={4}>
        Set a New Password
      </Heading>

      {isSuccess ? (
        <Alert
          status="success"
          flexDirection="column"
          alignItems="center"
          justifyContent="center"
          textAlign="center"
          variant="solid"
          my={8}
        >
          <AlertIcon boxSize="40px" mr={0} mb={4} />
          <AlertTitle>Password Reset Successfully</AlertTitle>
          <AlertDescription>
            Go to{" "}
            <BlitzLink href={Routes.LoginPage()} passHref>
              <Link textDecoration="underline" fontWeight="bold">
                login page
              </Link>
            </BlitzLink>
          </AlertDescription>
        </Alert>
      ) : (
        <Form
          submitText="Reset Password"
          schema={ResetPasswordWithoutToken}
          initialValues={{ password: "", passwordConfirmation: "" }}
          onSubmit={async (values) => {
            try {
              await resetPasswordMutation({ ...values, token: query.token as string })
            } catch (error) {
              if (error.name === "ResetPasswordError") {
                return {
                  [FORM_ERROR]: error.message,
                }
              } else {
                return {
                  [FORM_ERROR]: "Sorry, we had an unexpected error. Please try again.",
                }
              }
            }
          }}
          buttonProps={{
            colorScheme: "lightBlue",
            color: "brand.expertBlue",
          }}
        >
          <PasswordField name="password" label="New Password" variant="filled" />
          <PasswordField
            name="passwordConfirmation"
            label="Confirm New Password"
            variant="filled"
          />
        </Form>
      )}
      <Center mt={4}>
        <BlitzLink href={Routes.LoginPage()} passHref>
          <Link>Login</Link>
        </BlitzLink>
      </Center>
    </>
  )
}

ResetPasswordPage.redirectAuthenticatedTo = "/"
ResetPasswordPage.getLayout = (page) => <AuthLayout title="Reset Your Password">{page}</AuthLayout>

export default ResetPasswordPage
