import { SignupForm } from "app/auth/components/SignupForm"
import AuthLayout from "app/auth/layouts/AuthLayout"
import { BlitzPage } from "blitz"

const SignupPage: BlitzPage = () => {
  return (
    <>
      <SignupForm />
    </>
  )
}

SignupPage.redirectAuthenticatedTo = "/"
SignupPage.getLayout = (page) => <AuthLayout title="Sign Up">{page}</AuthLayout>

export default SignupPage
