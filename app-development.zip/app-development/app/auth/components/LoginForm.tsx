import { Box, Center, Heading, Link, Text } from "@chakra-ui/react"
import login from "app/auth/mutations/login"
import { Login } from "app/auth/validations"
import { Form, FORM_ERROR } from "app/core/components/Form"
import PasswordField from "app/core/components/PasswordField"
import TextField from "app/core/components/TextField"
import { AuthenticationError, Link as BlitzLink, Routes, useMutation } from "blitz"

type LoginFormProps = {
  onSuccess?: () => void
}

export const LoginForm = (props: LoginFormProps) => {
  const [loginMutation] = useMutation(login)

  return (
    <>
      <Heading size="sm" textAlign="center" mt={4}>
        Log into your account
      </Heading>
      <Form
        submitText="Login"
        schema={Login}
        initialValues={{ email: "", password: "" }}
        onSubmit={async (values) => {
          try {
            await loginMutation(values)
            props.onSuccess?.()
          } catch (error) {
            if (error instanceof AuthenticationError) {
              return { [FORM_ERROR]: "Sorry, those credentials are invalid" }
            } else if (error.name === "EmailVerificationError") {
              return {
                [FORM_ERROR]: (
                  <Text>
                    Sorry, your email is not verified. Go to{" "}
                    <BlitzLink href={Routes.ResendVerificationPage()} passHref>
                      <Link textDecoration="underline" fontWeight="bold">
                        email verification page
                      </Link>
                    </BlitzLink>{" "}
                    to request instructions.
                  </Text>
                ),
              }
            } else {
              return {
                [FORM_ERROR]:
                  "Sorry, we had an unexpected error. Please try again. - " + error.toString(),
              }
            }
          }
        }}
        buttonProps={{
          colorScheme: "lightBlue",
          color: "brand.expertBlue",
        }}
      >
        <TextField name="email" label="Email" placeholder="Email" variant="filled" />
        <PasswordField name="password" label="Password" placeholder="Password" variant="filled" />
        <Box textAlign="right" mt={4}>
          <BlitzLink href={Routes.ForgotPasswordPage()} passHref>
            <Link>Forgot your password?</Link>
          </BlitzLink>
        </Box>
      </Form>
      <Center mt={4}>
        <BlitzLink href={Routes.SignupPage()} passHref>
          <Link>Sign Up</Link>
        </BlitzLink>
      </Center>
    </>
  )
}

export default LoginForm
