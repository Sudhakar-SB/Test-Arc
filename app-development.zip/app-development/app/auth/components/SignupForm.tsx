import {
  Alert,
  AlertDescription,
  AlertIcon,
  AlertTitle,
  Center,
  Heading,
  HStack,
  Link,
} from "@chakra-ui/react"
import signup from "app/auth/mutations/signup"
import { Signup } from "app/auth/validations"
import { Form, FORM_ERROR } from "app/core/components/Form"
import PasswordField from "app/core/components/PasswordField"
import TextField from "app/core/components/TextField"
import { Link as BlitzLink, Routes, useMutation } from "blitz"

type SignupFormProps = {
  onSuccess?: () => void
}

export const SignupForm = (props: SignupFormProps) => {
  const [signupMutation, { isSuccess }] = useMutation(signup)

  return (
    <>
      <Heading size="sm" textAlign="center" mt={4}>
        Sign up for a new account
      </Heading>
      {isSuccess ? (
        <Alert
          status="success"
          flexDirection="column"
          alignItems="center"
          justifyContent="center"
          textAlign="center"
          variant="solid"
          my={8}
        >
          <AlertIcon boxSize="40px" mr={0} mb={4} />
          <AlertTitle>Signed up successfully!</AlertTitle>
          <AlertDescription>
            You will receive an email from us in order to verify your email address. In case you
            don't get it, go to{" "}
            <BlitzLink href={Routes.ResendVerificationPage()} passHref>
              <Link>email verification page</Link>
            </BlitzLink>{" "}
            to request instructions.
          </AlertDescription>
        </Alert>
      ) : (
        <Form
          submitText="Create Account"
          schema={Signup}
          initialValues={{ email: "", password: "" }}
          onSubmit={async (values) => {
            try {
              await signupMutation(values)
              props.onSuccess?.()
            } catch (error) {
              if (error.code === "P2002" && error.meta?.target?.includes("email")) {
                // This error comes from Prisma
                return { email: "This email is already being used" }
              } else {
                return { [FORM_ERROR]: error.toString() }
              }
            }
          }}
          buttonProps={{
            colorScheme: "lightBlue",
            color: "brand.expertBlue",
          }}
        >
          <HStack spacing={4} mt={6} alignItems="flex-start">
            <TextField
              name="firstName"
              label="First Name"
              placeholder="John"
              outerProps={{ mt: 0 }}
              variant="filled"
              isRequired
            />
            <TextField
              name="lastName"
              label="Last Name"
              placeholder="Doe"
              isRequired
              variant="filled"
            />
          </HStack>

          <TextField
            name="email"
            label="Email"
            placeholder="john@example.com"
            isRequired
            variant="filled"
          />
          <PasswordField
            name="password"
            label="Password"
            placeholder="Type password"
            isRequired
            variant="filled"
          />
          <PasswordField
            name="passwordConfirmation"
            label="Confirm Password"
            placeholder="Repeat password"
            isRequired
            variant="filled"
          />
          <TextField
            name="phone"
            label="Phone (optional)"
            placeholder="+49XXXXXXXXXXX"
            variant="filled"
          />
        </Form>
      )}

      <Center mt={4}>
        <BlitzLink href={Routes.LoginPage()} passHref>
          <Link>Login</Link>
        </BlitzLink>
      </Center>
    </>
  )
}

export default SignupForm
