import { Signup } from "app/auth/validations"
import { resolver, SecurePassword } from "blitz"
import db from "db"
import resendVerification from "./resendVerification"

export default resolver.pipe(
  resolver.zod(Signup),
  async ({ email, password, firstName, lastName, phone }, ctx) => {
    const hashedPassword = await SecurePassword.hash(password.trim())
    const user = await db.user.create({
      data: {
        email: email.toLowerCase().trim(),
        hashedPassword,
        role: "USER",
        firstName,
        lastName,
        phone,
      },
      select: { id: true, firstName: true, lastName: true, phone: true, email: true, role: true },
    })

    await resendVerification({ email }, ctx)

    return user
  }
)
