import { hash256, resolver } from "blitz"
import db from "db"
import { VerifyEmail } from "../validations"

export class VerifyEmailError extends Error {
  name = "VerifyEmailError"
  message = "Email verification link is invalid or it has expired."
}

export default resolver.pipe(resolver.zod(VerifyEmail), async ({ token }) => {
  // 1. Try to find this token in the database
  const hashedToken = hash256(token)
  const possibleToken = await db.token.findFirst({
    where: { hashedToken, type: "EMAIL_VERIFICATION" },
    include: { user: true },
  })

  // 2. If token not found, error
  if (!possibleToken) {
    throw new VerifyEmailError()
  }
  const savedToken = possibleToken

  // 3. Delete token so it can't be used again
  await db.token.delete({ where: { id: savedToken.id } })

  // 4. If token has expired, error
  if (savedToken.expiresAt < new Date()) {
    throw new VerifyEmailError()
  }

  // 5. Since token is valid, now we can update the user's email verification flag
  await db.user.update({
    where: { id: savedToken.userId },
    data: { isEmailVerified: true },
  })

  return true
})
