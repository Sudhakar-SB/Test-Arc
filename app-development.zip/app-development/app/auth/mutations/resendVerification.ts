import { generateToken, hash256, resolver } from "blitz"
import db from "db"
import buildVerifyEmailMailer from "../../../mailers/buildVerifyEmailMailer"
import moment from "moment"
import { ResendVerification } from "../validations"

const EMAIL_VERIFICATION_TOKEN_EXPIRATION_IN_HOURS = 24

export default resolver.pipe(resolver.zod(ResendVerification), async ({ email }) => {
  // 1. Get the user
  const user = await db.user.findFirst({ where: { email: email.toLowerCase() } })

  // 2. Generate the token and expiration date.
  const token = generateToken()
  const hashedToken = hash256(token)
  const expiresAt = moment(new Date())
    .add(EMAIL_VERIFICATION_TOKEN_EXPIRATION_IN_HOURS, "h")
    .toDate()

  // 3. If user with this email was found
  if (user && !user.isEmailVerified) {
    // 4. Delete any existing email verification tokens
    await db.token.deleteMany({ where: { type: "EMAIL_VERIFICATION", userId: user.id } })
    // 5. Save this new token in the database.
    await db.token.create({
      data: {
        user: { connect: { id: user.id } },
        type: "EMAIL_VERIFICATION",
        expiresAt,
        hashedToken,
        sentTo: user.email,
      },
    })
    // 6. Send the email
    await buildVerifyEmailMailer({ user, to: user.email, token }).send()
  } else {
    // 7. If no user found wait the same time so attackers can't tell the difference
    await new Promise((resolve) => setTimeout(resolve, 750))
  }

  // 8. Return the same result whether a password reset email was sent or not
  return
})
