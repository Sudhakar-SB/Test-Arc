import * as z from "zod"

const password = z
  .string()
  .min(6)
  .max(100)
  .regex(/^(?=.*[A-Za-z])(?=.*[0-9]).*$/, "Must contain at least 1 alphabet & 1 number")

export const Signup = z
  .object({
    firstName: z.string(),
    lastName: z.string(),
    email: z.string().email(),
    password,
    passwordConfirmation: password,
    phone: z.string().optional(),
  })
  .refine((data) => data.password === data.passwordConfirmation, {
    message: "Passwords don't match",
    path: ["passwordConfirmation"], // set the path of the error
  })

export const Login = z.object({
  email: z.string().email(),
  password: z.string(),
})

export const ForgotPassword = z.object({
  email: z.string().email(),
})

export const ResetPasswordWithoutToken = z
  .object({
    password: password,
    passwordConfirmation: password,
  })
  .refine((data) => data.password === data.passwordConfirmation, {
    message: "Passwords don't match",
    path: ["passwordConfirmation"], // set the path of the error
  })

export const ResetPassword = ResetPasswordWithoutToken.and(
  z.object({
    token: z.string(),
  })
)

export const ChangePassword = z.object({
  currentPassword: z.string(),
  newPassword: password,
})

export const ResendVerification = z.object({
  email: z.string().email(),
})

export const VerifyEmail = z.object({
  token: z.string(),
})
