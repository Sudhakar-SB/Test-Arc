import { Routes } from ".blitz"
import { RouteUrlObject } from "@blitzjs/core"
import { AddPersonIcon, AddSampleIcon, AddTestTubeIcon } from "app/theme/icons"

export const CONTAINER_MAX_WIDTH = 1160
export const CONTAINER_MAX_WIDTH_PX = `${CONTAINER_MAX_WIDTH}px`

export const CONTENT_WIDTH = 640
export const CONTENT_WIDTH_PX = `${CONTENT_WIDTH}px`

export const HEADER_HEIGHT = 64
export const HEADER_HEIGHT_PX = `${HEADER_HEIGHT}px`

export const CONTENT_HEIGHT = `calc(100vh - ${HEADER_HEIGHT_PX})`

export const SIDEBAR_WIDTH = 220
export const SIDEBAR_WIDTH_PX = `${SIDEBAR_WIDTH}px`

type MainRoute = {
  key: string
  href: RouteUrlObject
  label: string
  icon: (any) => JSX.Element
  infoText: string
}

export const MAIN_ROUTES: MainRoute[] = [
  {
    key: "subjects",
    href: Routes.SubjectsPage(),
    label: "Subject(s) Registration",
    icon: AddPersonIcon,
    infoText: "To register every new subject and myLifeDNA™️ StarterKit",
  },
  {
    key: "sample-pickup",
    href: Routes.SamplePickupPage(),
    label: "Sample Pickup",
    icon: AddSampleIcon,
    infoText: "To organize the sample pick-up",
  },
  {
    key: "activation",
    href: Routes.Dashboard(),
    label: "Product Activation",
    icon: AddTestTubeIcon,
    infoText: "To activate your sequencing product(s) (e. g. myLifeHeart™️)",
  },
  {
    key: "analysis",
    href: Routes.Dashboard(),
    label: "Medical Results",
    icon: AddTestTubeIcon,
    infoText: "To view and download your genomic result.",
  },
]
