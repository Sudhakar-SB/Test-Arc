import {
  Box,
  Button,
  Container,
  Divider,
  FormControl,
  FormLabel,
  Heading,
  HStack,
  Input,
  InputGroup,
  SimpleGrid,
  Stack,
  Text,
} from "@chakra-ui/react"
import Layout from "app/core/layouts/Layout"
import lightOrDark from "app/theme/utils/lightOrDark"
import { BlitzPage } from "blitz"
import React from "react"
import { colors } from "../../theme/theme"

const StyleGuide: BlitzPage = () => {
  return (
    <Container py={8}>
      <Heading as="h1">StyleGuide</Heading>

      <Divider my={4} />

      <Heading size="lg" mb={4}>
        Colors
      </Heading>

      {Object.keys(colors).map((primaryKey) => {
        return (
          <SimpleGrid columns={3} spacing={4} mb={4} alignItems="center" key={primaryKey}>
            <Heading size="md" mb={4}>
              {primaryKey}
            </Heading>
            {Object.keys(colors[primaryKey]).map((secondaryKey) => {
              const bgKey = `${primaryKey}.${secondaryKey}`
              const bgColor = colors[primaryKey][secondaryKey]
              const textColor = lightOrDark(bgColor) === "light" ? "black" : "white"
              return (
                <Box bg={bgKey} p={4} justifyContent="space-between" key={bgKey}>
                  <Text casing="capitalize" color={textColor}>
                    {primaryKey} {secondaryKey}
                  </Text>
                  <Text casing="capitalize" color={textColor}>
                    {colors[primaryKey][secondaryKey].toUpperCase()}
                  </Text>
                </Box>
              )
            })}
          </SimpleGrid>
        )
      })}

      <Divider my={4} />

      <Heading size="lg" mb={4}>
        Typography
      </Heading>

      <Stack spacing={6} mb={6}>
        <Heading as="h1" size="4xl">
          4XL as H1
        </Heading>
        <Heading as="h2" size="3xl" isTruncated>
          3XL as H2
        </Heading>
        <Heading as="h2" size="2xl">
          2XL as H2
        </Heading>
        <Heading as="h2" size="xl">
          XL as H2
        </Heading>
        <Heading as="h3" size="lg">
          LG as H3
        </Heading>
        <Heading as="h4" size="md">
          MD as H4
        </Heading>
        <Heading as="h5" size="sm">
          SM as H5
        </Heading>
        <Heading as="h6" size="xs">
          XS as H6
        </Heading>
      </Stack>

      <Text color="gray.regular" isTruncated>
        Single line truncated text: Lorem ipsum is placeholder text commonly used in the graphic,
        print, and publishing industries for previewing layouts and visual mockups.
      </Text>

      <Text noOfLines={2}>
        Multi line truncated text: "The quick brown fox jumps over the lazy dog" is an
        English-language pangram; a sentence that contains all of the letters of the English
        alphabet. Owing to its existence, Chakra was created.
      </Text>

      <Divider my={4} />

      <Heading size="lg" mb={4}>
        Buttons
      </Heading>

      <Heading size="md" mb={4}>
        Sizes
      </Heading>
      <HStack spacing={4}>
        {["sm", "md", "lg"].map((size) => {
          return (
            <Button key={`button-${size}`} colorScheme="expertBlue" size={size}>
              {size}
            </Button>
          )
        })}
      </HStack>

      <Heading size="md" my={4}>
        Color Schemes &amp; Variants
      </Heading>
      {["expertBlue", "cyan", "gray"].map((colorScheme) => {
        return (
          <React.Fragment key={`button-${colorScheme}`}>
            <Heading size="sm">{colorScheme}</Heading>
            <HStack spacing={4} my={4}>
              {["solid", "outline", "link"].map((variant) => {
                return (
                  <Button
                    key={`button-${colorScheme}-${variant}`}
                    colorScheme={colorScheme}
                    variant={variant}
                    {...(colorScheme === "lightBlue" ? { color: "blue.900" } : {})}
                  >
                    {variant}
                  </Button>
                )
              })}
            </HStack>
          </React.Fragment>
        )
      })}

      <Heading size="lg" mb={4}>
        Colors
      </Heading>
      <HStack spacing={4}></HStack>

      <Divider my={4} />

      <Heading size="lg" mb={4}>
        Form Elements
      </Heading>

      <HStack spacing={4}>
        <FormControl id="name">
          <FormLabel>Name</FormLabel>
          <InputGroup>
            <Input type="text" />
          </InputGroup>
        </FormControl>
      </HStack>
    </Container>
  )
}

StyleGuide.getLayout = (page) => <Layout title="StyleGuide">{page}</Layout>

export default StyleGuide
