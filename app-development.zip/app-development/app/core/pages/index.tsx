import { Box, Center, Circle, Link, SimpleGrid, Text } from "@chakra-ui/layout"
import Layout from "app/core/layouts/Layout"
import { BlitzPage, Link as BlitzLink } from "blitz"
import { CONTENT_HEIGHT, MAIN_ROUTES } from "../constants"

const Dashboard: BlitzPage = () => {
  return (
    <Center minHeight={CONTENT_HEIGHT} p={16}>
      <SimpleGrid columns={[1, 2, 4]} spacing={[10, 20]}>
        {MAIN_ROUTES.map(({ key, href, label, icon: Icon, infoText }, index) => (
          <BlitzLink key={key} href={href} passHref>
            <Link
              display="flex"
              flexDirection="column"
              alignItems="center"
              color="brand.yellowMarker"
              _hover={{ color: "yellow.200" }}
            >
              <Circle backgroundColor="transparent" height={7} width={7}>
                <Text fontSize="lg" color="brand.expertBlue">
                  {index + 1}
                </Text>
              </Circle>
              <Icon height={["100px", "140px"]} width="auto" color="currentColor" my={4} />
              <Text fontSize="lg" color="brand.expertBlue" textAlign="center">
                {label}
              </Text>
              <Box flexGrow={1} />
              <Text
                mt={2}
                minHeight={"90px"}
                fontSize="sm"
                color="gray.700"
                backgroundColor="brand.lightGray"
                p={3}
                maxWidth={210}
                borderRadius="4px"
              >
                {infoText}
              </Text>
            </Link>
          </BlitzLink>
        ))}
      </SimpleGrid>
    </Center>
  )
}

Dashboard.authenticate = true
Dashboard.suppressFirstRenderFlicker = true
Dashboard.getLayout = (page) => <Layout title="Dashboard">{page}</Layout>

export default Dashboard
