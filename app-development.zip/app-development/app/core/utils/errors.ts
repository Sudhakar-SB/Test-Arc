// inspired by https://github.com/blitz-js/blitz/blob/canary/packages/core/src/errors.ts
import SuperJson from "superjson"

const errorProps = ["name", "message", "code", "statusCode", "meta"]

if (process.env.JEST_WORKER_ID === undefined) {
  SuperJson.allowErrorProps(...errorProps)
}

export class BadGatewayError extends Error {
  name = "BadGatewayError"
  statusCode = 502
  constructor(message = "Bad Gateway 502") {
    super(message)
  }
  get _clearStack() {
    return true
  }
}
if (process.env.JEST_WORKER_ID === undefined) {
  SuperJson.registerClass(BadGatewayError, {
    identifier: "BadGatewayError",
    allowProps: errorProps,
  })
}
