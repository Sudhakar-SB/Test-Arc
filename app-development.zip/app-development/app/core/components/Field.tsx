import {
  FormControl,
  FormControlProps,
  FormErrorMessage,
  FormHelperText,
  FormLabel,
  Tooltip,
  TooltipProps,
} from "@chakra-ui/react"
import React, { FC, PropsWithoutRef } from "react"
import { useField } from "react-final-form"

export interface FieldProps {
  name: string
  label?: string
  outerProps?: PropsWithoutRef<FormControlProps>
  helperText?: React.ReactNode
  isRequired?: boolean
  isReadOnly?: boolean
  isDisabled?: boolean
  errorAsTooltip?: boolean
}

const Field: FC<FieldProps> = ({
  name,
  label,
  helperText,
  outerProps,
  isRequired,
  isReadOnly,
  isDisabled,
  errorAsTooltip,
  children,
}) => {
  const {
    meta: { touched, error, submitError, submitting },
  } = useField(name)

  const normalizedError = Array.isArray(error) ? error.join(", ") : error || submitError

  const InputWrapper = errorAsTooltip ? Tooltip : React.Fragment
  const inputWrapperProps: Omit<TooltipProps, "children"> = errorAsTooltip
    ? {
        label: normalizedError,
        hasArrow: true,
        placement: "right",
        isOpen: true,
      }
    : {}

  return (
    <FormControl
      mt={6}
      {...outerProps}
      id={name}
      isRequired={isRequired}
      isInvalid={touched && !!normalizedError}
      isDisabled={isDisabled || submitting}
      isReadOnly={isReadOnly}
    >
      {label && <FormLabel>{label}</FormLabel>}

      <InputWrapper {...inputWrapperProps}>{children}</InputWrapper>

      {helperText && <FormHelperText>{helperText}</FormHelperText>}

      {!errorAsTooltip && <FormErrorMessage>{normalizedError}</FormErrorMessage>}
    </FormControl>
  )
}

export default Field
