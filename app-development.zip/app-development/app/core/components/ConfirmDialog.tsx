import {
  AlertDialog,
  AlertDialogBody,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogOverlay,
  Button,
  ButtonProps,
} from "@chakra-ui/react"
import React, { FC, useRef, useState } from "react"

interface Props {
  trigger: FC<{ onClick: (e: React.SyntheticEvent<HTMLButtonElement>) => void }>
  title?: string
  body?: string
  colorScheme?: ButtonProps["colorScheme"]
  ctaText?: string
  onConfirm?: () => any | Promise<() => any>
  onTriggerClick?: (e: React.SyntheticEvent<HTMLButtonElement>) => void
}

const ConfirmDialog: FC<Props> = ({
  trigger: Trigger,
  title = "Are you sure?",
  body = "Are you sure? You can't undo this action afterwards.",
  colorScheme = "red",
  ctaText = "Confirm",
  onTriggerClick,
  onConfirm,
}) => {
  const [isOpen, setIsOpen] = useState(false)
  const onClose = () => setIsOpen(false)
  const cancelRef = useRef<HTMLButtonElement>(null)

  const handleConfirm = async () => {
    onConfirm && (await onConfirm())
    onClose()
  }

  return (
    <>
      <Trigger
        onClick={(e) => {
          onTriggerClick && onTriggerClick(e)
          setIsOpen(true)
        }}
      />

      <AlertDialog isOpen={isOpen} leastDestructiveRef={cancelRef} onClose={onClose}>
        <AlertDialogOverlay>
          <AlertDialogContent>
            <AlertDialogHeader fontSize="lg" fontWeight="bold">
              {title}
            </AlertDialogHeader>

            <AlertDialogBody>{body}</AlertDialogBody>

            <AlertDialogFooter>
              <Button ref={cancelRef} onClick={onClose}>
                Cancel
              </Button>
              <Button colorScheme={colorScheme} onClick={handleConfirm} ml={3}>
                {ctaText}
              </Button>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialogOverlay>
      </AlertDialog>
    </>
  )
}

export default ConfirmDialog
