import { Box, Link, Text, VStack } from "@chakra-ui/layout"
import { Link as BlitzLink, useRouter } from "blitz"
import { FC } from "react"
import { MAIN_ROUTES } from "../constants"
import Sidebar, { SidebarProps } from "./Sidebar"

const MainSidebar: FC<SidebarProps> = ({ ...restProps }) => {
  const router = useRouter()
  return (
    <Sidebar
      topComponent={
        <VStack align="start" spacing={10} mt={10}>
          {MAIN_ROUTES.map(({ key, href, label, icon: Icon }) => {
            const isActive = router.pathname === href.pathname
            return (
              <BlitzLink key={key} href={href} passHref>
                <Link
                  display="flex"
                  w="full"
                  alignItems="center"
                  color="brand.yellowMarker"
                  background={isActive ? "white" : undefined}
                  p={4}
                  _hover={{ color: "yellow.200", background: isActive ? "white" : "gray.50" }}
                  _focus={{ boxShadow: "none" }}
                >
                  <Icon height={["32px"]} width="auto" color="currentColor" mr={3} />
                  <Text fontSize="md" fontWeight="bold" color="brand.expertBlue">
                    {label}
                  </Text>
                </Link>
              </BlitzLink>
            )
          })}
        </VStack>
      }
      bottomComponent={
        <Box my={4}>
          <Link>Support</Link>
        </Box>
      }
      {...restProps}
    />
  )
}

export default MainSidebar
