import { Select, SelectProps } from "@chakra-ui/react"
import { forwardRef } from "react"
import { useField } from "react-final-form"
import Field, { FieldProps } from "./Field"

interface SelectOption {
  label: string
  value: string | number
}

interface Props extends FieldProps, Omit<SelectProps, "ref" | "name"> {
  options: SelectOption[]
  placeholder?: string
}

const SelectField = forwardRef<HTMLSelectElement, Props>((props, ref) => {
  const { name, helperText, isRequired, isReadOnly, options, ...inputProps } = props
  const { input } = useField(name)

  return (
    <Field {...props}>
      <Select {...input} {...inputProps} ref={ref} isDisabled={isReadOnly}>
        {options.map(({ label, value }) => {
          return (
            <option key={value} value={value}>
              {label}
            </option>
          )
        })}
      </Select>
    </Field>
  )
})

export default SelectField
