import { Alert, AlertIcon } from "@chakra-ui/alert"
import { Button, ButtonProps } from "@chakra-ui/button"
import { Flex } from "@chakra-ui/layout"
import { PropsWithoutRef, ReactNode } from "react"
import { Form as FinalForm, FormProps as FinalFormProps } from "react-final-form"
import * as z from "zod"
export { FORM_ERROR } from "final-form"

export interface FormProps<S extends z.ZodType<any, any>>
  extends FinalFormProps,
    Omit<PropsWithoutRef<JSX.IntrinsicElements["form"]>, "onSubmit"> {
  /** All your form fields */
  children?: ReactNode
  /** Text to display in the submit button */
  submitText?: string
  backText?: string
  schema?: S
  onSubmit: FinalFormProps<z.infer<S>>["onSubmit"]
  onBack?: () => void
  initialValues?: FinalFormProps<z.infer<S>>["initialValues"]
  buttonProps?: ButtonProps
}

export function Form<S extends z.ZodType<any, any>>({
  children,
  submitText,
  backText = "Back",
  schema,
  initialValues,
  onSubmit,
  onBack,
  buttonProps,
  ...restProps
}: FormProps<S>) {
  return (
    <FinalForm
      initialValues={initialValues}
      validate={(values) => {
        if (!schema) return
        try {
          schema.parse(values)
        } catch (error) {
          // console.log(error)
          return error.formErrors.fieldErrors
        }
      }}
      onSubmit={onSubmit}
      render={(renderProps) => {
        const { handleSubmit, submitting, submitError } = renderProps
        return (
          <Flex as="form" direction="column" onSubmit={handleSubmit}>
            {/* Form fields supplied as children are rendered here */}
            {typeof children === "function" ? children(renderProps) : children}

            {submitError && (
              <Alert status="error" variant="solid" mt={8}>
                <AlertIcon />
                {submitError}
              </Alert>
            )}

            <Flex alignItems="center" mt={10}>
              {onBack && (
                <Button
                  type="button"
                  mr="auto"
                  colorScheme="expertBlue"
                  variant="outline"
                  onClick={onBack}
                >
                  {backText}
                </Button>
              )}

              {submitText && (
                <Button
                  ml="auto"
                  mr={onBack ? 0 : "auto"}
                  type="submit"
                  colorScheme="expertBlue"
                  isLoading={submitting}
                  {...buttonProps}
                >
                  {submitText}
                </Button>
              )}
            </Flex>
          </Flex>
        )
      }}
      {...restProps}
    />
  )
}

export default Form
