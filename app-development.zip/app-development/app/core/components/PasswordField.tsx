import { Icon, IconButton } from "@chakra-ui/react"
import TextField, { TextFieldProps } from "app/core/components/TextField"
import { FC, useState } from "react"
import { IoEye, IoEyeOff } from "react-icons/io5"

interface Props extends TextFieldProps {}

const PasswordField: FC<Props> = ({ type, ...props }) => {
  const [isVisible, setVisibility] = useState(false)
  return (
    <TextField
      type={isVisible ? "text" : "password"}
      inputRightElement={
        <IconButton
          isRound
          size="sm"
          variant="ghost"
          colorScheme="expertBlue"
          aria-label={`${isVisible ? "Hide" : "Show"} password`}
          onClick={() => setVisibility((visible) => !visible)}
        >
          <Icon as={isVisible ? IoEyeOff : IoEye} height={5} width={5} />
        </IconButton>
      }
      {...props}
    />
  )
}

export default PasswordField
