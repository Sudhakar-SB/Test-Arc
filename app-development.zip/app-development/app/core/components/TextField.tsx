import {
  Input,
  InputGroup,
  InputLeftElement,
  InputProps,
  InputRightElement,
} from "@chakra-ui/react"
import { forwardRef } from "react"
import { useField } from "react-final-form"
import Field, { FieldProps } from "./Field"

export interface TextFieldProps extends FieldProps, Omit<InputProps, "ref" | "name"> {
  type?: "text" | "password" | "email" | "number"
  placeholder?: string
  inputLeftElement?: React.ReactNode
  inputRightElement?: React.ReactNode
}

const TextField = forwardRef<HTMLInputElement, TextFieldProps>((props, ref) => {
  const {
    helperText,
    isRequired,
    isReadOnly,
    outerProps,
    errorAsTooltip,
    inputLeftElement,
    inputRightElement,
    ...inputProps
  } = props
  const { input } = useField(props.name, {
    parse: props.type === "number" ? (v) => (v ? Number(v) : null) : (v) => v,
  })

  const pattern = isRequired ? ".*\\S+.*" : undefined
  const title = isRequired ? "This field is required" : undefined

  return (
    <Field {...props}>
      <InputGroup>
        {inputLeftElement && <InputLeftElement>{inputLeftElement}</InputLeftElement>}
        <Input {...input} {...inputProps} ref={ref} pattern={pattern} title={title} />
        {inputRightElement && <InputRightElement>{inputRightElement}</InputRightElement>}
      </InputGroup>
    </Field>
  )
})

export default TextField
