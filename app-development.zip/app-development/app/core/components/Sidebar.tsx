import { Box, BoxProps, Flex } from "@chakra-ui/layout"
import { FC } from "react"
import { CONTENT_HEIGHT, HEADER_HEIGHT_PX, SIDEBAR_WIDTH_PX } from "../constants"

export interface SidebarProps extends BoxProps {
  topComponent?: React.ReactNode
  bottomComponent?: React.ReactNode
}

const Sidebar: FC<SidebarProps> = ({ topComponent, bottomComponent, ...restProps }) => {
  return (
    <Box
      w={SIDEBAR_WIDTH_PX}
      h={CONTENT_HEIGHT}
      position="sticky"
      top={HEADER_HEIGHT_PX}
      left={0}
      {...restProps}
    >
      <Box
        background="gray.100"
        pos="absolute"
        right={0}
        top={0}
        bottom={0}
        height="full"
        width="1920px"
        zIndex={-1}
      />
      <Flex direction="column" justifyContent="space-between" h="full" overflow="auto">
        {topComponent && <div>{topComponent}</div>}
        {bottomComponent && <div>{bottomComponent}</div>}
      </Flex>
    </Box>
  )
}

export default Sidebar
