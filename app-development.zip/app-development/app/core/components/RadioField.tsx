import { Radio, RadioGroup, RadioGroupProps, Stack, StackProps } from "@chakra-ui/react"
import { forwardRef } from "react"
import { useField } from "react-final-form"
import Field, { FieldProps } from "./Field"

interface RadioOption {
  label: string
  value: string | number
}

interface Props extends FieldProps, Omit<RadioGroupProps, "ref" | "name" | "children"> {
  options: RadioOption[]
  placeholder?: string
  stackDirection?: StackProps["direction"]
}

const RadioField = forwardRef<HTMLDivElement, Props>((props, ref) => {
  const {
    name,
    helperText,
    isRequired,
    isReadOnly,
    options,
    isDisabled,
    stackDirection = "row",
    ...inputProps
  } = props
  const { input } = useField(name)

  return (
    <Field {...props}>
      <RadioGroup {...input} {...inputProps} ref={ref} defaultValue={input.value}>
        <Stack direction={stackDirection} spacing={6}>
          {options.map(({ label, value }) => {
            return (
              <Radio key={value} value={value} cursor={isDisabled ? "no-drop" : "pointer"}>
                {label}
              </Radio>
            )
          })}
        </Stack>
      </RadioGroup>
    </Field>
  )
})

export default RadioField
