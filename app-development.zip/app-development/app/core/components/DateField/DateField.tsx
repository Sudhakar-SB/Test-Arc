// https://gist.github.com/igoro00/99e9d244677ccafbf39667c24b5b35ed

import { Global } from "@emotion/react"
import { FC } from "react"
import ReactDatePicker, { ReactDatePickerProps } from "react-datepicker"
import "react-datepicker/dist/react-datepicker.css"
import { useField } from "react-final-form"
import Field, { FieldProps } from "../Field"
import datePickerStyles from "./styles"

interface Props extends FieldProps, Omit<Partial<ReactDatePickerProps>, "name"> {
  placeholder?: string
  isClearable?: boolean
  showPopperArrow?: boolean
}

const DateField: FC<Props> = (props) => {
  const {
    helperText,
    isRequired,
    isReadOnly,
    isDisabled,
    isClearable,
    showPopperArrow,
    placeholder,
    dateFormat = "dd.MM.yyyy",
    ...inputProps
  } = props
  const {
    input,
    meta: { submitting },
  } = useField(props.name)

  return (
    <>
      <Global styles={datePickerStyles} />
      <Field {...props}>
        <div className={`light-theme${isDisabled ? " disabled" : ""}`}>
          <ReactDatePicker
            selected={input.value}
            isClearable={isClearable}
            dateFormat={dateFormat}
            showPopperArrow={showPopperArrow}
            //input is white by default and there is no already defined class for it so I created a new one
            className="react-datepicker__input-text"
            disabled={isDisabled || submitting}
            autoComplete="off"
            placeholderText={placeholder}
            {...input}
            {...inputProps}
            required={isRequired}
          />
        </div>
      </Field>
    </>
  )
}

export default DateField
