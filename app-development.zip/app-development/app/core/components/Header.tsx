import { Box, Container, Flex, Heading, Link } from "@chakra-ui/react"
import { EmblemGraphic } from "app/theme/graphics"
import { Link as BlitzLink, Routes } from "blitz"
import React, { FC, Suspense } from "react"
import { CONTAINER_MAX_WIDTH_PX, HEADER_HEIGHT } from "../constants"
import UserDropdown, { UserDropdownLoader } from "./UserDropdown"

interface Props {}

export const headerLinkProps = {
  _hover: { textDecoration: "none", background: "expertBlue.700" },
  h: `${HEADER_HEIGHT}px`,
  px: 2,
}

const Header: FC<Props> = () => {
  return (
    <Box
      as="header"
      h={`${HEADER_HEIGHT}px`}
      background="brand.expertBlue"
      color="white"
      position="fixed"
      top={0}
      left={0}
      right={0}
      zIndex={10}
    >
      <Container
        maxW={CONTAINER_MAX_WIDTH_PX}
        display="flex"
        alignItems="center"
        justifyContent="space-between"
      >
        <Flex alignItems="center">
          <BlitzLink href={Routes.Dashboard()} passHref>
            <Link display="flex" alignItems="center" {...headerLinkProps}>
              <EmblemGraphic h="50px" w="auto" mr={4} />
              <Heading as="h1" fontSize="3xl">
                arcensus
              </Heading>
            </Link>
          </BlitzLink>
        </Flex>

        <Suspense fallback={<UserDropdownLoader />}>
          <UserDropdown />
        </Suspense>
      </Container>
    </Box>
  )
}

export default Header
