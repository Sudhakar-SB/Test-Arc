import { ChevronDownIcon } from "@chakra-ui/icons"
import {
  Avatar,
  Flex,
  FlexProps,
  HStack,
  Menu,
  MenuButton,
  MenuGroup,
  MenuItem,
  MenuList,
  Skeleton,
  SkeletonCircle,
  Text,
} from "@chakra-ui/react"
import logout from "app/auth/mutations/logout"
import { Routes, useMutation, useRouter } from "blitz"
import md5 from "md5"
import { FC } from "react"
import { useCurrentUser } from "../hooks/useCurrentUser"
import { headerLinkProps } from "./Header"

interface Props extends FlexProps {}

const UserDropdown: FC<Props> = ({ ...restProps }) => {
  const currentUser = useCurrentUser()
  const router = useRouter()
  const [logoutMutation] = useMutation(logout)

  if (!currentUser) {
    return <UserDropdownLoader />
  }

  const handleLogoutClick = async () => {
    await logoutMutation()
    router.push(Routes.LoginPage())
  }

  const { firstName, lastName, email } = currentUser
  const name = `${firstName} ${lastName}`
  const emailHash = md5(email.trim().toLowerCase())
  return (
    <Flex {...restProps}>
      {/* Weird quirk, MenuItem throws error without isLazy  */}
      {/* prop on Menu "Maximum update depth exceeded"  */}
      <Menu closeOnBlur isLazy>
        <MenuButton {...headerLinkProps}>
          <HStack spacing={3}>
            <Avatar
              h="30px"
              w="30px"
              bg="gray.300"
              name={name}
              src={`https://www.gravatar.com/avatar/${emailHash}`}
            />
            <Text>{name}</Text>
            <ChevronDownIcon />
          </HStack>
        </MenuButton>
        <MenuList color="black">
          <MenuGroup title={email}>
            <MenuItem onClick={handleLogoutClick}>Logout</MenuItem>
          </MenuGroup>
        </MenuList>
      </Menu>
    </Flex>
  )
}

export default UserDropdown

export const UserDropdownLoader = () => {
  return (
    <HStack spacing={3}>
      <SkeletonCircle size="30px" />
      <Skeleton height="16px" width="40px" />
      <Skeleton height="16px" width="60px" />
      <ChevronDownIcon />
    </HStack>
  )
}
