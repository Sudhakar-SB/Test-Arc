import { Box, BoxProps, Container } from "@chakra-ui/layout"
import { BackgroundGraphic } from "app/theme/graphics"
import { Head } from "blitz"
import { FC, ReactNode } from "react"
import Header from "../components/Header"
import MainSidebar from "../components/MainSidebar"
import { SidebarProps } from "../components/Sidebar"
import {
  CONTAINER_MAX_WIDTH_PX,
  CONTENT_HEIGHT,
  CONTENT_WIDTH,
  HEADER_HEIGHT_PX,
} from "../constants"

export interface LayoutProps extends BoxProps {
  title?: string
  children: ReactNode
  hasSidebar?: boolean
  sidebarComponent?: FC<SidebarProps>
}

const Layout: FC<LayoutProps> = ({
  title,
  children,
  hasSidebar,
  sidebarComponent: Sidebar = MainSidebar,
  ...restProps
}) => {
  return (
    <>
      <Head>
        <title>{title ? `${title} - Arcensus` : "Arcensus"}</title>
        <link rel="icon" href="/favicon.png" />
      </Head>

      <Header />

      <Box
        zIndex={-1}
        position="fixed"
        top={HEADER_HEIGHT_PX}
        bottom={0}
        right={0}
        left={0}
        minHeight={CONTENT_HEIGHT}
        minWidth="100vw"
        objectFit="cover"
      >
        <BackgroundGraphic height="auto" width="auto" objectFit="cover" />
      </Box>

      <Container
        maxW={CONTAINER_MAX_WIDTH_PX}
        minHeight={CONTENT_HEIGHT}
        mt={HEADER_HEIGHT_PX}
        display="flex"
      >
        {hasSidebar && <Sidebar />}
        <Box w={hasSidebar ? CONTENT_WIDTH : CONTAINER_MAX_WIDTH_PX} {...restProps}>
          {children}
        </Box>
      </Container>
    </>
  )
}

export default Layout
