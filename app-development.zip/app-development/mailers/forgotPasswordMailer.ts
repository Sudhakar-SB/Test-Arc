/* TODO - You need to add a mailer integration in `integrations/` and import here.
 *
 * The integration file can be very simple. Instantiate the email client
 * and then export it. That way you can import here and anywhere else
 * and use it straight away.
 */
import { User } from "db"
import mailgun from "integrations/mailgun"
import previewEmail from "preview-email"

type ResetPasswordMailer = {
  user: User
  to: string
  token: string
}

const forgotPasswordTemplate = `
<section style="font-family: Arial, sans-serif, 'Open Sans'; max-width: 500px; line-height: 1.5">
  <h1 style="color: #31477d">Dear {{firstName}},</h1>

  <p>Welcome to the arcensus portal</p>

  <p>
    To reset your password, click on the link below::<br>
    <a href="{{resetUrl}}" style="font-weight: bold; font-size: 20px"> Reset my password </a>
  </p>

  <p>
    If you require any further information, feel free to contact:<br>
    <a href="mailto:supportportal@arcensus-diagnostics.com"
      >supportportal@arcensus-diagnostics.com</a
    >
  </p>

  <p>
    Best Regards,<br>
    Your arcensus Portal
  </p>

  <p style="margin-top: 20px; color: #204c5c">
    arcensus GmbH<br>
    Goethestr. 20<br>
    18055 Rostock
  </p>

  <p>
    <a href="https://www.arcensus-diagnostics.com">www.arcensus-diagnostics.com</a>
  </p>

  <p style="margin-top: 30px; font-size: 10px; color: #9e9e9e; line-height: 1.2">
    Headquarter of the company and billing address:<br>
    arcensus GmbH, Goethestr. 20, 18055 Rostock, Germany<br><br>
    Managing Directors: Michael Schlenk, Christine Uekert<br><br>
    Registered seat: Rostock, registered with the commercial registers of the local court of Rostock
    HRB 15164 / VAT ID: DE338357136. This e-mail communication (and any attachment/s) is
    confidential and intended only for the individual(s) or entity named above and to others who
    have been specifically authorized to receive it. If you are not the intended recipient, please
    do not read, copy, use or disclose the contents of this communication to others. Please notify
    the sender that you have received this e-mail in error, by calling the phone number indicated or
    by e-mail, and delete the e-mail (including any attachment/s) subsequently. Thank you
  </p>
</section>
`

export function forgotPasswordMailer({ user, to, token }: ResetPasswordMailer) {
  // In production, set APP_ORIGIN to your production server origin
  const origin = process.env.APP_ORIGIN || process.env.BLITZ_DEV_SERVER_ORIGIN
  const resetUrl = `${origin}/reset-password?token=${token}`

  const msg = {
    from: process.env.MAILGUN_SENDER_EMAIL,
    to,
    subject: "Password Reset",
    html: forgotPasswordTemplate
      .replace(/{{firstName}}/g, user.firstName || "Portal user")
      .replace(/{{resetUrl}}/g, resetUrl),
  }

  return {
    async send() {
      if (process.env.NODE_ENV === "production") {
        mailgun.messages
          .create(process.env.MAILGUN_DOMAIN!, msg)
          .then((msg) => console.log(msg))
          .catch((err) => console.error(err))
      } else {
        // Preview email in the browser
        await previewEmail(msg)
      }
    },
  }
}
