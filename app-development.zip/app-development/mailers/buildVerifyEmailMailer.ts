/* TODO - You need to add a mailer integration in `integrations/` and import here.
 *
 * The integration file can be very simple. Instantiate the email client
 * and then export it. That way you can import here and anywhere else
 * and use it straight away.
 */
import { User } from "db"
import mailgun from "integrations/mailgun"
import previewEmail from "preview-email"

// Note: I'd prefer to have these as html, but reading from file local directory is too much trouble in NextJS/BlitzJS

const verifyEmailTemplate = `
<section style="font-family: Arial, sans-serif, 'Open Sans'; max-width: 500px; line-height: 1.5">

  <h1 style="color: #385391">Dear {{firstName}},</h1>

  <p>Welcome to the arcensus portal</p>

  <p>
    To verify your email, click the link below:<br>
    <a href="{{verifyUrl}}" style="font-weight: bold; font-size: 20px;">
      Confirm my e-mail address
    </a>
  </p>

  <div style="font-size: 12px; color: #333333">
    Use your arcensus portal to:
    <ol style="font-size: 12px; color: #333333">
      <li>
        Register your subject by providing
        <ul>
          <li>Subject information</li>
          <li>Family history</li>
          <li>Clinical information</li>
        </ul>
      </li>
      <li>To organize a shipment for your sample</li>
      <li>To view and download your medical report(s)</li>
    </ol>
  </div>

  <p>
    If you require any further information, feel free to contact:<br>
    <a href="mailto:supportportal@arcensus-diagnostics.com">supportportal@arcensus-diagnostics.com</a>
  </p>

  <p>
  Best Regards,<br>
  Your arcensus Portal
  </p>

  <p style="margin-top: 20px; color: #204C5C">
  arcensus GmbH<br>
  Goethestr. 20<br>
  18055 Rostock
  </p>

  <p>
    <a href="https://www.arcensus-diagnostics.com">www.arcensus-diagnostics.com</a>
  </p>

  <p style="margin-top: 30px; font-size: 10px; color: #9E9E9E; line-height: 1.2">
    Headquarter of the company and billing address:<br>
    arcensus GmbH, Goethestr. 20, 18055 Rostock, Germany<br><br>
    Managing Directors: Michael Schlenk, Christine Uekert<br><br>
    Registered seat: Rostock, registered with the commercial registers of the local court of Rostock HRB 15164 / VAT ID: DE338357136. This e-mail communication (and any attachment/s) is confidential and intended only for the individual(s) or entity named above and to others who have been specifically authorized to receive it. If you are not the intended recipient, please do not read, copy, use or disclose the contents of this communication to others. Please notify the sender that you have received this e-mail in error, by calling the phone number indicated or by e-mail, and delete the e-mail (including any attachment/s) subsequently. Thank you
  </p>

</section>
`

type Args = {
  user: User
  to: string
  token: string
}

function buildVerifyEmailMailer({ user, to, token }: Args) {
  // In production, set APP_ORIGIN to your production server origin
  const origin = process.env.APP_ORIGIN || process.env.BLITZ_DEV_SERVER_ORIGIN
  const verifyUrl = `${origin}/verify-email?token=${token}`

  const htmlContent = verifyEmailTemplate
    .replace(/{{firstName}}/g, user.firstName || "portal user")
    .replace(/{{verifyUrl}}/g, verifyUrl)

  const msg = {
    from: process.env.MAILGUN_SENDER_EMAIL,
    to,
    subject: "Email Verification",
    html: htmlContent,
  }

  return {
    async send() {
      if (process.env.NODE_ENV === "production") {
        mailgun.messages
          .create(process.env.MAILGUN_DOMAIN!, msg)
          .then((msg) => console.log(msg))
          .catch((err) => console.error(err))
      } else {
        // Preview email in the browser
        await previewEmail(msg)
      }
    },
  }
}

export default buildVerifyEmailMailer
