module.exports = {
  presets: ["blitz/babel"],
  plugins: [],
}
